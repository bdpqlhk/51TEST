# -*- coding: utf-8 -*-

import platform
import os

ISWINDOWS = platform.platform().startswith(("windows", "Windows"))

casepath = "/root/postman/testcase/"
environmentpath = "/root/postman/environment/"
caseresultpath = "/root/postman/testresult/"

#url配置
baseurl = {
    "dragnet": "http://172.16.116.121:7880/dragnet-growth-server/api/"
}

#环境配置
envconfig = {
    "dragnet": "172.16.116.121:7880",
    "comment": "172.16.117.225:9088",
    "platform": "192.168.0.121:7321",
    "trade": "172.16.117.181:7600",
    "epay": "172.16.117.181:7001"
}

#httprunner case路径相关配置
if ISWINDOWS:
    projpath = r"c:\tools\qatools"
    hrunlogpath = os.path.join(projpath, r"logs\hrun.log")
else:
    projpath = r"/root/qatools"
    hrunlogpath = os.path.join(projpath, "logs/hrun.log")

hruncasepath = os.path.join(projpath,"hruntestcase")
hrunscriptpath = os.path.join(projpath,"main-debug.py")
hrunreportpath = os.path.join(projpath,"reports")

# 支付回调地址
paycallback = "172.16.117.215:7095"
