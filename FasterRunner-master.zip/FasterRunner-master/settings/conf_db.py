#-*- coding: utf-8 -*-

# ***********************
# description：测试环境配置
# author：喻珩
# create time：2018.5.16
# ***********************

#db配置
dbconfig = {
    "dragnet": {
        "host": "192.168.0.175",
        "port": 3306,
        "user": "dragnet_all",
        "password": "DragnetV2@Test",
        "name": "dragnet"
    },
    "cms": {
        "host": "192.168.0.175",
        "port": 3306,
        "user": "dragnet_all",
        "password": "DragnetV2@Test",
        "name": "cms"
    },
    "trade": {
        "host": "172.16.117.219",
        "port": 3306,
        "user": "crm",
        "password": "474523",
        "name": "trade"
    },
    "comment": {
        "host": "172.16.117.219",
        "port": 3306,
        "user": "crm",
        "password": "crm",
        "name": "comment"
    },
    "sms":{
        "host": "192.168.1.216",
        "port": 3306,
        "user": "sms",
        "password": "sms123",
        "name": "sms"
    },
    "apiGatewayAdmin":{
        "host": "192.168.2.55",
        "port": 3306,
        "user": "root",
        "password": "sunlands_wh",
        "name": "apigateway"
    }
}


coupon_test_db = {
    'DB_HOST': '172.16.117.2',
    'DB_PORT':3306,
    'DB_USER':'loan_coupon_all',
    'DB_PWD': 'Loan#Coupon12',
    'DB_NAME':'loan_coupon'
}

ent_portal_test_db = {
    'DB_HOST': '172.16.117.226',
    'DB_PORT':3306,
    'DB_USER':'ent_all',
    'DB_PWD': 'ent',
    'DB_NAME':'ent_portal'
}

ehr_test_db = {
    'DB_HOST': '172.16.101.130',
    'DB_PORT':3306,
    'DB_USER':'bkuser',
    'DB_PWD': '123456',
    'DB_NAME':'ehr'
}

bk_ehr_test_db = {
    'DB_HOST': '172.16.101.130',
    'DB_PORT':3306,
    'DB_USER':'bkuser',
    'DB_PWD': '123456',
    'DB_NAME':'ehrbk'
}

refund_test_db = {
    'DB_HOST': '172.16.117.219',
    'DB_PORT':3306,
    'DB_USER':'crm',
    'DB_PWD': 'crm',
    'DB_NAME':'refund'
}

configcenter_test_db = {
    'DB_HOST': '192.168.0.50',
    'DB_PORT':3307,
    'DB_USER':'tars',
    'DB_PWD': 'tars2015',
    'DB_NAME':'TestDB'
}

workorder_db = {
    'DB_HOST': '172.16.101.130',
    'DB_PORT':3306,
    'DB_USER':'bkuser',
    'DB_PWD': '123456',
    'DB_NAME':'workorder'
}