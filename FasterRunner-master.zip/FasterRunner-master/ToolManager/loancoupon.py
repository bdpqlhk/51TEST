# -*- coding: utf-8 -*-
import json
import re
from qalib.MysqldbHelper import *
from settings.conf_db import  *
import requests
import logging
import datetime
from django.http import HttpResponse
logger = logging.getLogger('HttpRunnerManager')
from rest_framework.decorators import api_view


@api_view(["POST"])
def generateLoanCoupon(request):
    print('test')
    received_json_data = json.loads(request.body)
    mobile = received_json_data['mobile']
    channel_id = received_json_data['channel_id']
    quota = received_json_data['quota']
    sql = "select * from loan_consultant_balance  where channel_id = %s and incent_amount > %s"
    db = DB(**coupon_test_db)
    fc = db.query(sql,[channel_id,quota])
    loancoupon = ''
    ss = ''
    for row in fc:
        data = {}
        data['consultantAccount'] = row[1]
        data['mobile'] = mobile
        data['channelId'] = channel_id
        data['quota'] = quota
        requrl = "http://192.168.0.121:8050/loancoupon-api-war/api/dragnetLoanCouponManage/generateLoanByMobile"
        headerdata = {"Content-Type": "application/json"}
        print(json.dumps(data))
        res = requests.post(requrl, data=json.dumps(data), headers=headerdata)
        ss = res.json()
        x = ss.get("flag")
        loancoupon = ss.get("data")
        if x == 1:
            break
        else:
            continue
    r = {'code': 0, 'msg': "sucess", 'data': loancoupon}
    if loancoupon == '':
        return HttpResponse(json.dumps(ss,ensure_ascii=False))
    else:
        return HttpResponse(json.dumps(r))

@api_view(["POST"])
def generateCoupon(request):
    received_json_data = json.loads(request.body)
    print(received_json_data)
    mobile = received_json_data['mobile']
    couponValue = received_json_data['couponValue']
    couponType = received_json_data['couponType']
    useTogether = received_json_data['useTogether']

    data = {"stuMobile": mobile, "couponType": couponType,"couponValue": couponValue, "validBegin": datetime.datetime.now().strftime('%Y-%m-%d 00:00:00'), "validEnd": (datetime.datetime.now()+ datetime.timedelta(days=7)).strftime('%Y-%m-%d 00:00:00'), "useTogether": useTogether, "limitCategoryFirst":"", "limitCategorySecond":"", "limitProduct":"", "createOrigin":"ENT_OP"}

    requrl = "http://172.16.117.215:7067/sv/rest/createAndBindCoupon"
    headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
    res = requests.post(requrl, data=data, headers=headerdata)
    ss = res.json()
    r = {'code': 0, 'msg': "sucess", 'data': ss}
    return HttpResponse(json.dumps(r))






