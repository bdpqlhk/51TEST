from django.core.exceptions import ObjectDoesNotExist
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.viewsets import GenericViewSet, ModelViewSet
from fastrunner import models, serializers
from FasterRunner import pagination
from rest_framework.response import Response
from fastrunner.utils import response
from fastrunner.utils import prepare
from fastrunner.utils.parser import Format, Parse
from fastrunner.utils.runner import DebugCode
from fastrunner.utils.tree import get_tree_max_id
from fastrunner.utils import loader
from django.db import DataError
import json
import requests


# Create your views here.

@api_view(["POST"])
def generateLoanCoupon(request):
    received_json_data = json.loads(request.body)
    # mobile = received_json_data['mobile']
    # channel_id = received_json_data['channel_id']
    # quota = received_json_data['quota']
    # sql = "select * from loan_consultant_balance  where channel_id = %s and incent_amount > %s"
    # db = DB(**coupon_test_db)
    # fc = db.query(sql,[channel_id,quota])
    # loancoupon = ''
    # ss = ''
    # for row in fc:
    #     data = {}
    #     data['consultantAccount'] = row[1]
    #     data['mobile'] = mobile
    #     data['channelId'] = channel_id
    #     data['quota'] = quota
    #     requrl = "http://192.168.0.121:8050/loancoupon-api-war/api/dragnetLoanCouponManage/generateLoanByMobile"
    #     headerdata = {"Content-Type": "application/json"}
    #     res = requests.post(requrl, data=json.dumps(data), headers=headerdata)
    #     ss = res.json()
    #     x = ss.get("flag")
    #     loancoupon = ss.get("data")
    #     if x == 1:
    #         break
    #     else:
    #         continue
    # r = {'code': 0, 'msg': "sucess", 'data': loancoupon}
    # if loancoupon == '':
    #     return Response(json.dumps(ss,ensure_ascii=False))
    # else:
    return Response(received_json_data)
