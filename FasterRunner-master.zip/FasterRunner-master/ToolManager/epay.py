# -*- coding: utf-8 -*-
import json
import requests
import logging
import debugtalk
from django.http import HttpResponse
from settings import config
from rest_framework.decorators import api_view

logger = logging.getLogger('HttpRunnerManager')

@api_view(["POST"])
def epay(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        epayurl = received_json_data['epayurl']
        payamount = received_json_data['payamount']
        # payNumber = received_json_data['payNumber']
        paymethon = received_json_data['paymethon']
        channelCode = received_json_data['channelCode']
        # totalAmount = received_json_data['totalAmount']
        # orderDetails = received_json_data['orderDetails']
        if epayurl == '':
            return HttpResponse("请输入epayurl")
        elif paymethon == '请选择':
            return HttpResponse("请选择支付方式")
        # elif payamount == '':
        #     payamount = received_json_data['totalAmount']
        else:
            #    创建订单获取订单信息
            # requrl = "http://192.168.0.121:8087/tool/createorder/createorder/"
            requrl = "http://127.0.0.1:8000/tool/createorder/createorder/"
            headerdata = {"Content-Type": "application/json"}
            res = requests.post(requrl, data=json.dumps(received_json_data), headers=headerdata)
            jsondata = json.loads(res.text)
            payNumber = jsondata.get("payNumber")
            orderNumber = jsondata.get("orderNumber")
            payamount = jsondata.get("totalAmount")
            # 支付金额为空时，支付金额等于下单金额
            if not payNumber:
                return HttpResponse(res.text)
            else:
                # if payamount == '':
                #     payamount = received_json_data['totalAmount']
                # if channelCode in ('OC_SCHOOL','OC_NEWDRAGNET'):
                #     payamount = int(4980)+int(126)
                timestamp = debugtalk.get_time_now()
                bizContent = {"payNumber":payNumber,"payBankId":paymethon,"payAmountInput":payamount,"orderNumber":orderNumber}
                data = {"method": "payOrder", "channelCode": "TRADE","timestamp":timestamp, "version": "1.0", "sign": 123, "signType": "MD5", "bizContent":str(bizContent)}
                #     获取sign值
                requrl = "http://192.168.0.121:7321/platform/makesign/md5makesign"
                headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
                res = requests.post(requrl, data=data, headers=headerdata)
                ss = res.json()
                makesign = ss.get("sign")
                #     订单支付
                epaydata = {"method": "payOrder", "channelCode": "TRADE","timestamp":timestamp, "version": "1.0", "sign": makesign, "signType": "MD5", "bizContent":str(bizContent)}
                epayurl = "http://" + epayurl + "/epay-war/ws/rest/execute"
                epay = requests.post(epayurl, data=epaydata, headers=headerdata)
                epayresponse = json.loads(epay.text)
                bankOrderNumber = epayresponse.get("bankOrderNumber")
                #支付回调
                paycallback(bankOrderNumber, paymethon, payamount)
                ss = {"orderNumber":orderNumber,"payNumber":payNumber}
                return HttpResponse(str(ss))



def paycallback(bankOrderNumber,paymethon,payamount):

    url = config.paycallback
    headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {}
    requrl = ""
    # 支付宝回调
    if paymethon == '20':
        data = {"is_success": "T", "out_trade_no": bankOrderNumber, "total_fee": payamount, "trade_status": "TRADE_SUCCESS", "callBackType": "2"}
        requrl = "http://"+ url + "/epay-war-demo/aliPayCallBack"
    # 微信回调
    elif paymethon == '41':
        data = {"return_code": "SUCCESS", "appid": "wx4b565a53aa146b0b", "bank_type":"CFT", "device_info": "WEB", "fee_type": "CNY", "is_subscribe": "N", "mch_id": "1288885001", "nonce_str": "z060K7RY9024fY77F3Ry38vyG4Wo78t8", "openid": "oRIbywJ94YwFmhYdzErkto175V4U", "trade_type": "NATIVE", "out_trade_no": bankOrderNumber, "total_fee": payamount, "callback_type": "1", "result_code": "SUCCESS"}
        requrl = "http://"+ url + "/epay-war-demo/wxPayCallBack"
    elif paymethon == '21':
        data = {"respCode": "00", "orderNumber": bankOrderNumber, "orderAmount":payamount, "callBackType": "2"}
        requrl = "http://"+ url + "/epay-war-demo/unionPayCallBack"
    res = requests.post(requrl, data=data, headers=headerdata)
    print("支付回调结果" + res.text)
    return HttpResponse(res.text)
















