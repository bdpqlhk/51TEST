# -*- coding: utf-8 -*-
import json
import re
from qalib.MysqldbHelper import *
from settings.conf_db import  *
import requests
import logging
from django.http import HttpResponse
import datetime
from dateutil.relativedelta import relativedelta
import platform
import shutil
from qalib.MysqldbHelper import *
from settings.conf_db import  *
import sys
import calendar
import paramiko
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse, StreamingHttpResponse
from django.shortcuts import render_to_response
import json
import requests
import logging
import debugtalk
from django.http import HttpResponse
from settings import config
from ApiManager.utils.common import get_ajax_msg, set_filter_session

from ApiManager.models import ehr_module_employee, ProjectInfo

logger = logging.getLogger('HttpRunnerManager')



def view(request, id):
    """
    ehr数据构造
    :param request:
    :param id: str or int：当前页
    :return:
    """
    logger.info('testing')
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                requestparam = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logging.debug('项目信息解析异常：{requestparam}'.format(requestparam=requestparam))
                return HttpResponse('项目信息解析异常')
        else:
            filter_query = set_filter_session(request)
            employee_id = request.POST.get('employee_id')
            date = request.POST.get('date')
            a = t_employee_base_info(employee_id)
            plan = t_schedule_plan(employee_id,date)
            attendance = t_work_attendance_statistic_details_record(employee_id,date)
            tips = {'员工性质，1：正式员工，2：非正式员工，3：参培员工','work_state任职状态，1：实习，2：试用，3：正式，4：离职办理中，5：离职,6：入职办理中,7:停薪待返岗'}
            if not a:
                tips = {}
            manage_info = {
                'account': acount,
                't_employee_base_info': a,
                'employee_base_info_tips': tips,
                't_schedule_plan': plan,
                't_work_attendance_statistic_details_record': attendance,
                'info':filter_query
            }
            return render_to_response('ehrdata_list.html', manage_info)
    else:
        return HttpResponseRedirect("/api/login/")

# 人员表信息查询
def t_employee_base_info(employee_id):
        sql = "select employee_id,contract_type,city,type,pay_city,is_51,num_51_agency,work_state,country,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,org_id from t_employee_base_info where employee_id = %s"
        db = DB(**ehr_test_db)
        fc = db.query(sql,[employee_id])
        list = []
        for row in fc:
            ss = {}
            ss['employee_id'] = row[0]
            ss['contract_type'] = row[1]
            ss['city'] = row[2]
            ss['type'] = row[3]
            ss['pay_city'] = row[4]
            ss['is_51'] = row[5]
            ss['num_51_agency'] = row[6]
            ss['work_state'] = row[7]
            ss['country'] = row[8]
            ss['id_num'] = row[9]
            ss['entry_dt'] = row[10]
            ss['train_salary'] = row[11]
            ss['base_salary_before'] = row[12]
            ss['base_salary'] = row[13]
            ss['pos_salary_before'] = row[14]
            ss['pos_salary'] = row[15]
            ss['leave_work_statu_before'] = row[16]
            ss['the_last_dt'] = row[17]
            ss['start_train_dt'] = row[18]
            ss['end_train_dt'] = row[19]
            ss['org_id'] = row[20]
            list.append(ss)
        return list



def t_work_attendance_statistic_details_record(employee_id,date):
    firstDay = ''
    lastDay = ''
    if not date:
        firstDay = datetime.date.today() - relativedelta(months=+1)
        lastDay = datetime.date.today()
    else:
        ye = str(date)[0:4]
        da = str(date)[-2:]
        ss = getMonthFirstDayAndLastDay(ye, da)
        firstDay = ss['firstDay']
        lastDay = ss['lastDay']
    print(firstDay, lastDay)
    sql = "select record_id,late_minute,leaveearly_minute,checkin_time,date,unpunctual_times,no_attend_times,no_attend_days,hours,annual_days,thing_days,bussiness_days,sick_days,mate_days,marrage_days,funeral_days,collateral_funeral_days,paternity_days,antenatal_days,overtime_days,overtime_pay,injuery_days from t_work_attendance_statistic_details_record where  employee_id = %s and date BETWEEN %s and %s"
    db = DB(**ehr_test_db)
    fc = db.query(sql,[employee_id,firstDay,lastDay])
    list = []
    for row in fc:
        ss = {}
        ss['record_id'] = row[0]
        ss['late_minute'] = row[1]
        ss['leaveearly_minute'] = row[2]
        ss['checkin_time'] = row[3]
        ss['date'] = row[4]
        ss['unpunctual_times'] = row[5]
        ss['no_attend_times'] = row[6]
        ss['no_attend_days'] = row[7]
        ss['hours'] = row[8]
        ss['annual_days'] = row[9]
        ss['thing_days'] = row[10]
        ss['bussiness_days'] = row[11]
        ss['sick_days'] = row[12]
        ss['mate_days'] = row[13]
        ss['marrage_days'] = row[14]
        ss['funeral_days'] = row[15]
        ss['collateral_funeral_days'] = row[16]
        ss['paternity_days'] = row[17]
        ss['antenatal_days'] = row[18]
        ss['overtime_days'] = row[19]
        ss['overtime_pay'] = row[20]
        ss['injuery_days'] = row[21]
        list.append(ss)
    print(list)
    return list


def t_schedule_plan(employee_id,date):
    firstDay = ''
    lastDay = ''
    if not date:
        firstDay = datetime.date.today() - relativedelta(months=+1)
        lastDay = datetime.date.today()
    else:
        ye = str(date)[0:4]
        da = str(date)[-2:]
        ss = getMonthFirstDayAndLastDay(ye, da)
        firstDay = ss['firstDay']
        lastDay = ss['lastDay']
    lastmonth = datetime.date.today() - relativedelta(months=+1)
    nowtoday = datetime.date.today()
    # print(lastmonth,nowtoday)
    sql = "select id,work_date,schedule_dict_id,status from t_schedule_plan where  employee_id = %s and work_date BETWEEN %s and %s"
    db = DB(**ehr_test_db)
    fc = db.query(sql,[employee_id,firstDay,lastDay])
    list = []
    for row in fc:
        ss = {}
        ss['id'] = row[0]
        ss['work_date'] = row[1]
        ss['schedule_dict_id'] = row[2]
        ss['status'] = row[3]
        list.append(ss)
    return list


def edit_t_employee_base_info(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        employee_id = paramcommon(received_json_data['employee_id'])
        contract_type = paramcommon(received_json_data['contract_type'])
        city = paramcommon(received_json_data['city'])
        type = paramcommon(received_json_data['type'])
        pay_city = paramcommon(received_json_data['pay_city'])
        is_51 = paramcommon(received_json_data['is_51'])
        num_51_agency = paramcommon(received_json_data['num_51_agency'])
        work_state = paramcommon(received_json_data['work_state'])
        id_num = paramcommon(received_json_data['id_num'])
        entry_dt = paramcommon(received_json_data['entry_dt'])
        train_salary = paramcommon(received_json_data['train_salary'])
        base_salary_before = paramcommon(received_json_data['base_salary_before'])
        base_salary = paramcommon(received_json_data['base_salary'])
        pos_salary_before = paramcommon(received_json_data['pos_salary_before'])
        pos_salary = paramcommon(received_json_data['pos_salary'])
        leave_work_statu_before = paramcommon(received_json_data['leave_work_statu_before'])
        the_last_dt = paramcommon(received_json_data['the_last_dt'])
        start_train_dt = paramcommon(received_json_data['start_train_dt'])
        end_train_dt = paramcommon(received_json_data['end_train_dt'])
        org_id = paramcommon(received_json_data['org_id'])
        # print(contract_type,city,type,pay_city,is_51,num_51_agency,work_state,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,org_id,employee_id)
        sql = "update t_employee_base_info set contract_type = %s, city=%s, type=%s, pay_city=%s, is_51=%s, num_51_agency=%s, work_state=%s, id_num=%s, entry_dt=%s, train_salary=%s, base_salary_before=%s, base_salary=%s, pos_salary_before=%s, pos_salary=%s, leave_work_statu_before=%s, the_last_dt=%s, start_train_dt=%s, end_train_dt=%s, org_id=%s where employee_id = %s"
        db = DB(**ehr_test_db)
        fc = db.modify(sql,[contract_type,city,type,pay_city,is_51,num_51_agency,work_state,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,org_id,employee_id])
        return HttpResponse("sucess")


def edit_attendance_statistic(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        record_id = paramcommon(received_json_data['record_id'])
        late_minute = paramcommon(received_json_data['late_minute'])
        leaveearly_minute = paramcommon(received_json_data['leaveearly_minute'])
        checkin_time = paramcommon(received_json_data['checkin_time'])
        date = paramcommon(received_json_data['date'])
        unpunctual_times = paramcommon(received_json_data['unpunctual_times'])
        no_attend_times = paramcommon(received_json_data['no_attend_times'])
        no_attend_days = paramcommon(received_json_data['no_attend_days'])
        hours = paramcommon(received_json_data['hours'])
        annual_days = paramcommon(received_json_data['annual_days'])
        thing_days = paramcommon(received_json_data['thing_days'])
        bussiness_days = paramcommon(received_json_data['bussiness_days'])
        sick_days = paramcommon(received_json_data['sick_days'])
        mate_days = paramcommon(received_json_data['mate_days'])
        marrage_days = paramcommon(received_json_data['marrage_days'])
        funeral_days = paramcommon(received_json_data['funeral_days'])
        collateral_funeral_days = paramcommon(received_json_data['collateral_funeral_days'])
        paternity_days = paramcommon(received_json_data['paternity_days'])
        antenatal_days = paramcommon(received_json_data['antenatal_days'])
        overtime_days = paramcommon(received_json_data['overtime_days'])
        overtime_pay = paramcommon(received_json_data['overtime_pay'])
        injuery_days = paramcommon(received_json_data['injuery_days'])
        # print(contract_type,city,type,pay_city,is_51,num_51_agency,work_state,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,org_id,employee_id)
        sql = "update t_work_attendance_statistic_details_record set late_minute=%s,leaveearly_minute=%s,checkin_time=%s,date=%s,unpunctual_times=%s,no_attend_times=%s,no_attend_days=%s,hours=%s,annual_days=%s,thing_days=%s,bussiness_days=%s,sick_days=%s,mate_days=%s,marrage_days=%s,funeral_days=%s,collateral_funeral_days=%s,paternity_days=%s,antenatal_days=%s,overtime_days=%s,overtime_pay=%s,injuery_days=%s where record_id = %s"
        db = DB(**ehr_test_db)
        fc = db.modify(sql,[late_minute,leaveearly_minute,checkin_time,date,unpunctual_times,no_attend_times,no_attend_days,hours,annual_days,thing_days,bussiness_days,sick_days,mate_days,marrage_days,funeral_days,collateral_funeral_days,paternity_days,antenatal_days,overtime_days,overtime_pay,injuery_days,record_id])
        return HttpResponse("sucess")


def edit_t_schedule_plan(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        id = paramcommon(received_json_data['id'])
        work_date = paramcommon(received_json_data['work_date'])
        schedule_dict_id = paramcommon(received_json_data['schedule_dict_id'])
        status = paramcommon(received_json_data['status'])
      # print(contract_type,city,type,pay_city,is_51,num_51_agency,work_state,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,org_id,employee_id)
        sql = "update t_schedule_plan set schedule_dict_id=%s,status=%s where id = %s and status = 0"
        db = DB(**ehr_test_db)
        fc = db.modify(sql,[schedule_dict_id,status,id])
        return HttpResponse("sucess")



def copy_t_schedule_plan(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        id = paramcommon(received_json_data['id'])
        # work_date = paramcommon(received_json_data['work_date'])
        date = paramcommon(received_json_data['date'])
        # employee_id = paramcommon(received_json_data['employee_id'])
        # schedule_dict_id = paramcommon(received_json_data['schedule_dict_id'])
        # audit_state = paramcommon(received_json_data['audit_state'])
        # status = paramcommon(received_json_data['status'])

        sql = "select employee_id,schedule_dict_id,audit_state,status from t_schedule_plan where  id = %s"
        db = DB(**ehr_test_db)
        fc = db.query(sql, [id])
        list = []
        for row in fc:
            employee_id = row[0]
            schedule_dict_id = row[1]
            audit_state = row[2]
            status = row[3]

        sql = '''INSERT INTO `ehr`.`t_schedule_plan` (`employee_id`,`schedule_dict_id`,`work_date`, `create_person`, `audit_state`, `status`) VALUES (%s, %s,%s, 'auto', %s, %s)'''
        db = DB(**ehr_test_db)
        fc = db.modify(sql,[employee_id,schedule_dict_id,date,audit_state,status])
        return HttpResponse("sucess")


def paramcommon(param):
    if param in ('None', ''):
       return None
    elif param.find("年"):
        c = param.replace("年", "-")
        d = c.replace("月", "-")
        e = d.replace("日","")
        return e




def getMonthFirstDayAndLastDay(year=None, month=None):
    """
    :param year: 年份，默认是本年，可传int或str类型
    :param month: 月份，默认是本月，可传int或str类型
    :return: firstDay: 当月的第一天，datetime.date类型
              lastDay: 当月的最后一天，datetime.date类型
    """
    if year:
        year = int(year)
    else:
        year = datetime.date.today().year

    if month:
        month = int(month)
    else:
        month = datetime.date.today().month

    # 获取当月第一天的星期和当月的总天数
    firstDayWeekDay, monthRange = calendar.monthrange(year, month)

    # 获取当月的第一天
    firstDay = datetime.date(year=year, month=month, day=1)
    lastDay = datetime.date(year=year, month=month, day=monthRange)
    responsedata = {}
    responsedata['firstDay'] = firstDay
    responsedata['lastDay'] = lastDay
    return responsedata










