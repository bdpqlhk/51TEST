#-*- coding:utf-8 -*-
# ***********************
# description：mqtool页面调用接口
# author：喻珩
# create time：2018.6.6
# ***********************

import json
import logging

from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response

from ApiManager.models import MqToolInfo
from ApiManager.utils.common import get_ajax_msg, set_filter_session
from ApiManager.utils.pagination import get_pager_info

from qalib.mq.operation import del_mqtool_data, copy_mqtool_data
from qalib.mq.common import mqtool_info_logic
from qalib.mq.rocketmq import SendCommonMsgClient

logger = logging.getLogger("ToolManager")

def mqtool_list(request, id):
    """
        mq工具列表
        :param request:
        :param id: str or int：当前页
        :return:
    """
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                mqtoolinfo = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logging.error('mq工具信息解析异常：{mqtoolinfo}'.format(mqtoolinfo=mqtoolinfo))
                return HttpResponse('mq工具信息解析异常')
            if mqtoolinfo.get('mode') == 'del':
                msg = del_mqtool_data(mqtoolinfo.pop('id'))
            elif mqtoolinfo.get('mode') == 'copy':
                msg = copy_mqtool_data(mqtoolinfo.get('data').pop('index'), mqtoolinfo.get('data').pop('name'))
            return HttpResponse(get_ajax_msg(msg, 'ok'))

        else:
            filter_query = set_filter_session(request)
            mqtoollist = get_pager_info(
                MqToolInfo, filter_query, '/tool/rocketmq/mqtool_list/', id)
            mqtool_info = {
                'account': acount,
                'mqtools': mqtoollist[1],
                'page_list': mqtoollist[0],
                'info': filter_query
            }
            return render_to_response('tools/mqtool_list.html', mqtool_info)
    else:
        return HttpResponseRedirect("/api/login/")


def add_mqtool(request):
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                mqtool_info = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logger.error('mq工具信息解析异常：{mqtool_info}'.format(mqtool_info=mqtool_info))
                return 'mq工具信息解析异常'
            msg = mqtool_info_logic(**mqtool_info)
            return HttpResponse(get_ajax_msg(msg, '/tool/rocketmq/mqtool_list/1/'))
        elif request.method == 'GET':
            manage_info = {
                'account': acount,
                'project': ProjectInfo.objects.all().values('project_name').order_by('-create_time'),
            }
            return render_to_response('tools/add_mqtool.html', manage_info)
    else:
        return HttpResponseRedirect("/api/login/")


def edit_mqtool(request, id=None):
    """
       编辑mq工具
       :param request:
       :param id:
       :return:
       """
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                mqtool_info = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logger.error('mq工具信息解析异常：{mqtool_info}'.format(mqtool_info=mqtool_info))
                return 'mq工具信息解析异常'
            msg = mqtool_info_logic(type=False, **mqtool_info)
            return HttpResponse(get_ajax_msg(msg, '/tool/rocketmq/mqtool_list/1/'))
        elif request.method == 'GET':
            mqtool_info = MqToolInfo.objects.get_mqtool_by_id(id)
            manage_info = {
                'account': acount,
                'project': ProjectInfo.objects.all().values('project_name').order_by('-create_time'),
                "info": mqtool_info[0]
            }
            return render_to_response('tools/add_mqtool.html', manage_info)
    else:
        return HttpResponseRedirect("/api/login/")


def send_msg(request):
    """
    发送消息（向rocketmq proxy发送请求）
    :param request:
    :return:
    """
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                mqtool_info = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logger.error('mq工具信息解析异常：{mqtool_info}'.format(mqtool_info=mqtool_info))
                return 'mq工具信息解析异常'
            msg_body = json.loads(mqtool_info["msg_body"])
            commonMsgClient = SendCommonMsgClient(
                topic=mqtool_info["msg_topic"],
                tag=mqtool_info["topic_tag"],
                appid=mqtool_info["appid"],
                secretkey=mqtool_info["secretkey"],
                producerid=mqtool_info["producerid"])
            data = commonMsgClient.send(mqtool_info["proxyurl"], json.dumps(msg_body))
            return HttpResponse(json.dumps(data))
    else:
        return HttpResponseRedirect("/api/login/")
    return HttpResponse("result test")