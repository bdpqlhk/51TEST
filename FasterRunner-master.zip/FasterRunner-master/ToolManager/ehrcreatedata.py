# -*- coding: utf-8 -*-

import datetime

from ApiManager.models import ehr_module_employee

from qalib.MysqldbHelper import *
from settings.conf_db import  *

import json

import logging
from django.http import HttpResponse
from qalib.common import idcard_generator
import debugtalk
from ToolManager.ehrData import getMonthFirstDayAndLastDay


logger = logging.getLogger('HttpRunnerManager')


from django.core.exceptions import ObjectDoesNotExist

# 根据模板新建员工表
def insert_t_employee_base_info(request):
    global employee_id
    logger.info('testing')
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        id = received_json_data['id']
        attendance_date = received_json_data['date']
    try:
        ehrdata = ehr_module_employee.objects.get(id=id)
    except ObjectDoesNotExist:
        return '复制异常，请重试'
    # 获取模板数据
    employee_id_263 = debugtalk.gen_order_number()
    contract_type = ehrdata.contract_type
    city = ehrdata.city
    org_id = ehrdata.org_id
    type = ehrdata.type
    pay_city = ehrdata.pay_city
    is_51 = ehrdata.is_51
    num_51_agency = ehrdata.num_51_agency
    work_state = ehrdata.work_state
    country = ehrdata.country
    id_num = idcard_generator()
    entry_dt = ehrdata.entry_dt
    train_salary = ehrdata.train_salary
    base_salary_before = ehrdata.base_salary_before
    base_salary = ehrdata.base_salary
    pos_salary_before = ehrdata.pos_salary_before
    pos_salary = ehrdata.pos_salary
    leave_work_statu_before = ehrdata.leave_work_statu_before
    the_last_dt = ehrdata.the_last_dt
    start_train_dt = ehrdata.start_train_dt
    end_train_dt = ehrdata.end_train_dt
    organization_source = ehrdata.organization_source
    work_category = ehrdata.work_category

    regular_salary_before = ehrdata.regular_salary_before
    regular_salary_after = ehrdata.regular_salary_after
    regular_dt = ehrdata.regular_dt
    regular_type = ehrdata.regular_type

    salary_change_before = ehrdata.salary_change_before
    salary_change_after = ehrdata.salary_change_after
    salary_change_pos_before = ehrdata.salary_change_pos_before
    salary_change_pos_after = ehrdata.salary_change_pos_after
    salary_change_dt = ehrdata.salary_change_dt
    salary_change_type = ehrdata.salary_change_type
    attendance_statistic = ehrdata.attendance_statistic
    schedule_plan = ehrdata.schedule_plan

    # print(employee_id_263,contract_type,city,org_id, type,pay_city,is_51,num_51_agency,work_state,country,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt)
    # 插入花名册数据
    sql = "INSERT INTO t_employee_base_info (`employee_id_263`,`contract_type`,`city`, `org_id`, `type`,`pay_city`,`is_51`,`num_51_agency`,`work_state`,`country`,`id_num`,`entry_dt`,`train_salary`,`base_salary_before`,`base_salary`,`pos_salary_before`,`pos_salary`,`leave_work_statu_before`,`the_last_dt`,`start_train_dt`,`end_train_dt`,`work_category`,`name`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,'tester')"
    db = DB(**ehr_test_db)
    fc = db.modify(sql,[employee_id_263,contract_type,city,org_id, type,pay_city,is_51,num_51_agency,work_state,country,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,work_category])

    # 查询员工编号
    sql2 = "select employee_id from t_employee_base_info where employee_id_263 = %s"
    db2 = DB(**ehr_test_db)
    fc12 = db2.query(sql2, [employee_id_263])
    for row in fc12:
        employee_id = str(row[0])


    # 获取考勤月的第一天和最后一天
    ye = str(attendance_date)[0:4]
    da = str(attendance_date)[-2:]
    ss = getMonthFirstDayAndLastDay(ye, da)
    begin = ss['firstDay']
    end = ss['lastDay']



    # # # 插入bk数据用于工资核算
    employeeformdate = str(end).replace("-", "")[-6:]
    sqlbk = "INSERT INTO t_employee_base_info_bk" + employeeformdate +  "(`employee_id`,`employee_id_263`,`contract_type`,`city`, `org_id`, `type`,`pay_city`,`is_51`,`num_51_agency`,`work_state`,`country`,`id_num`,`entry_dt`,`train_salary`,`base_salary_before`,`base_salary`,`pos_salary_before`,`pos_salary`,`leave_work_statu_before`,`the_last_dt`,`start_train_dt`,`end_train_dt`,`work_category`,`name`) VALUES (%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,'tester')"
    dbbk = DB(**bk_ehr_test_db)
    bkinsert = dbbk.modify(sqlbk, [employee_id,employee_id_263,contract_type,city,org_id, type,pay_city,is_51,num_51_agency,work_state,country,id_num,entry_dt,train_salary,base_salary_before,base_salary,pos_salary_before,pos_salary,leave_work_statu_before,the_last_dt,start_train_dt,end_train_dt,work_category])


    # 插入考勤信息，包括考勤统计和排班信息
    insertattendance = insert_attendance_statistic(employee_id,begin,end)
    # # # 插入转正表
    insertregular = insert_t_employee_regular_record(employee_id, organization_source, regular_salary_before, regular_salary_after, regular_dt, regular_type)
    # # # 插入调薪表
    insertchargesalary = insert_t_employee_salary_change_record(employee_id, organization_source,salary_change_before, salary_change_after, salary_change_pos_before, salary_change_pos_after, salary_change_dt, salary_change_type)

    # # 更新考勤信息
    updateattendance = update_attendance_statistic(employee_id,attendance_statistic,attendance_date,end)

    # # 更新排班信息
    updateschedule = update_schedule_plan(employee_id, schedule_plan, attendance_date,end)
    ss = {'employee_id':employee_id,'employee_id_263':employee_id_263,'id_num':id_num}
    return HttpResponse(json.dumps(ss))

def insert_attendance_statistic(employee_id,begin,end):
    # ye = str(attendance_date)[0:4]
    # da = str(attendance_date)[-2:]
    # ss = getMonthFirstDayAndLastDay(ye, da)
    # begin = ss['firstDay']
    # end = ss['lastDay']
    for i in range((end - begin).days + 1):
        day = begin + datetime.timedelta(days=i)
        week = day.weekday()
        schedule_dict_id = ''
        if str(day) in ("2018-06-18","2018-04-30","2018-05-01"):
            schedule_dict_id = '169'
        elif week == 6 or week == 5:
            schedule_dict_id = '169'
        else:
            schedule_dict_id = '167'
        sql = '''INSERT INTO `ehr`.`t_schedule_plan` (`schedule_dict_id`, `employee_id`,`work_date`, `create_person`, `audit_state`, `status`) VALUES (%s, %s,%s, 'auto', '2', '0')'''
        sql2 = '''INSERT INTO `ehr`.`t_work_attendance_statistic_details_record` (`employee_id`, `date`, `checkin_time`, `checkout_time`) VALUES (%s,%s,%s,%s)'''
        db = DB(**ehr_test_db)
        fc = db.modify(sql,[schedule_dict_id,employee_id,day])
        d1 = str(day) + ' 09:30:00'
        d2 = str(day) + ' 19:00:00'
        checkin_time = datetime.datetime.strptime(d1, '%Y-%m-%d %H:%M:%S')
        checkout_time = datetime.datetime.strptime(d2, '%Y-%m-%d %H:%M:%S')
        db2 = DB(**ehr_test_db)
        fc2 = db2.modify(sql2, [employee_id, day, checkin_time,checkout_time])
    return HttpResponse("sucess")



def insert_t_employee_regular_record(employee_id,source,salary_before,salary_after,regular_dt,regular_type):
    sql = '''INSERT INTO `ehr`.`t_employee_regular_record` (`employee_id`, `source`, `salary_before`, `salary_after`, `regular_dt`, `regular_type`, `status`) VALUES (%s,%s,%s,%s,%s,%s,'0')'''
    db = DB(**ehr_test_db)
    fc = db.modify(sql, [employee_id,source,salary_before,salary_after,regular_dt,regular_type])
    return HttpResponse("sucess")


def insert_t_employee_salary_change_record(employee_id, source,salary_before, salary_after, pos_salary_before, pos_salary_after, change_dt, salary_change_type):
    sql = '''INSERT INTO `ehr`.`t_employee_salary_change_record` (`employee_id`, `source`,`salary_before`, `salary_after`, `pos_salary_before`, `pos_salary_after`, `change_dt`, `salary_change_type`, `status`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'0')'''
    db = DB(**ehr_test_db)
    fc = db.modify(sql, [employee_id, source,salary_before, salary_after, pos_salary_before, pos_salary_after, change_dt, salary_change_type])
    return HttpResponse("sucess")


def  update_attendance_statistic(employee_id,attendance_statistic,attendance_date,end):
    array = json.loads(attendance_statistic)
    for i in array:
        data = array[i]
        if len(i) < 2:
            i = '0'+ i
        print(i)
        if i ==  '00':
            break
        elif i  not in ('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'):
            break
        elif i > str(end)[-2:] :
            break
        else:
            date = attendance_date + '-'+ i
            late_minute = data['late_minute']
            leaveearly_minute = data['leaveearly_minute']
            checkin_time = date + ' ' + data['checkin_time']
            checkout_time = date + ' ' + data['checkout_time']
            unpunctual_times = data['unpunctual_times']
            no_attend_times = data['no_attend_times']
            no_attend_days = data['no_attend_days']
            hours = data['hours']
            annual_days = data['annual_days']
            thing_days = data['thing_days']
            bussiness_days = data['bussiness_days']
            sick_days = data['sick_days']
            mate_days = data['mate_days']
            marrage_days = data['marrage_days']
            funeral_days = data['funeral_days']
            collateral_funeral_days = data['collateral_funeral_days']
            paternity_days = data['paternity_days']
            antenatal_days = data['antenatal_days']
            overtime_days = data['overtime_days']
            overtime_pay = data['overtime_pay']
            injuery_days = data['injuery_days']
            sql = "update t_work_attendance_statistic_details_record set late_minute=%s,leaveearly_minute=%s,checkin_time=%s,checkout_time=%s,unpunctual_times=%s,no_attend_times=%s,no_attend_days=%s,hours=%s,annual_days=%s,thing_days=%s,bussiness_days=%s,sick_days=%s,mate_days=%s,marrage_days=%s,funeral_days=%s,collateral_funeral_days=%s,paternity_days=%s,antenatal_days=%s,overtime_days=%s,overtime_pay=%s,injuery_days=%s where employee_id = %s and date = %s"
            db = DB(**ehr_test_db)
            fc = db.modify(sql, [late_minute, leaveearly_minute, checkin_time,checkout_time,unpunctual_times, no_attend_times,
                                 no_attend_days, hours, annual_days, thing_days, bussiness_days, sick_days, mate_days,
                                 marrage_days, funeral_days, collateral_funeral_days, paternity_days, antenatal_days,
                                 overtime_days, overtime_pay, injuery_days,employee_id,date])
    return HttpResponse("sucess")



def  update_schedule_plan(employee_id,schedule_plan,attendance_date,end):
    array = json.loads(schedule_plan)
    for i in array:
        data = array[i]
        if len(i) < 2:
            i = '0'+ i
        print(i)
        if i ==  '00':
            break
        elif i  not in ('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'):
            break
        elif i > str(end)[-2:] :
            break
        else:
            work_date = attendance_date + '-'+ i
            schedule_dict_id = data['schedule_dict_id']
            status = data['status']
            sql = "update t_schedule_plan set schedule_dict_id=%s,status=%s where employee_id = %s and work_date = %s"
            db = DB(**ehr_test_db)
            fc = db.modify(sql, [schedule_dict_id,status,employee_id,work_date])
    return HttpResponse("sucess")






