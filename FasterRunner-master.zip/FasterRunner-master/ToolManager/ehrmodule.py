
import json
import logging

from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render_to_response
from django.db import DataError

from ApiManager.models import ehr_module_employee
from ApiManager.utils.common import get_ajax_msg, set_filter_session
from ApiManager.utils.pagination import get_pager_info

from qalib.mq.operation import del_mqtool_data, copy_mqtool_data
from qalib.mq.common import mqtool_info_logic
from qalib.mq.rocketmq import SendCommonMsgClient
from django.core.exceptions import ObjectDoesNotExist

logger = logging.getLogger("ToolManager")

def ehrmodule_list(request, id):
    """
        ehr数据构造
        :param request:
        :param id: str or int：当前页
        :return:
    """
    logger.info('testing')
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                ehrmodule = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logging.error('ehr数据构造解析异常：{ehrmodule}'.format(ehrmodule=ehrmodule))
                return HttpResponse('ehr数据构造解析异常')
            if ehrmodule.get('mode') == 'del':
                msg = del_ehrmodule_data(ehrmodule.pop('id'))
            elif ehrmodule.get('mode') == 'copy':
                msg = copy_ehrmodule_data(ehrmodule.get('data').pop('index'), ehrmodule.get('data').pop('name'))
            return HttpResponse(get_ajax_msg(msg, 'ok'))

        else:
            filter_query = set_filter_session(request)
            ehrdatalist = get_pager_info(
                ehr_module_employee, filter_query, '/tool/ehrmodule/ehrmodule_list/', id)
            mqtool_info = {
                'account': acount,
                'ehrdata': ehrdatalist[1],
                'page_list': ehrdatalist[0],
                'info': filter_query
            }
            print(filter_query)
            return render_to_response('ehrmodule_list.html', mqtool_info)
    else:
        return HttpResponseRedirect("/api/login/")


def add_ehrmodule(request):
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                ehrmodule = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logger.error('信息解析异常：{ehrmodule}'.format(ehrmodule=ehrmodule))
                return '信息解析异常'
            msg = ehrdata_info_logic(**ehrmodule)
            return HttpResponse(get_ajax_msg(msg, '/tool/ehrmodule/ehrmodule_list/1/'))
        elif request.method == 'GET':
            manage_info = {
                'account': acount,
            }
            return render_to_response('add_ehrmodule.html', manage_info)
    else:
        return HttpResponseRedirect("/api/login/")


def edit_ehrdata(request, id=None):
    """
       编辑
       :param request:
       :param id:
       :return:
       """
    if request.session.get('login_status'):
        acount = request.session["now_account"]
        if request.is_ajax():
            try:
                ehrdata_info = json.loads(request.body.decode('utf-8'))
            except ValueError:
                logger.error('信息解析异常：{ehrdata_info}'.format(ehrdata_info=ehrdata_info))
                return '信息解析异常'
            msg = ehrdata_info_logic(sss=False, **ehrdata_info)
            return HttpResponse(get_ajax_msg(msg, '/tool/ehrmodule/ehrmodule_list/1/'))
        elif request.method == 'GET':
            ehrdata_info = ehr_module_employee.objects.get_ehrmodule_by_id(id)
            manage_info = {
                'account': acount,
                'project': ProjectInfo.objects.all().values('project_name').order_by('-create_time'),
                "info": ehrdata_info[0]
            }
            return render_to_response('add_ehrmodule.html', manage_info)
    else:
        return HttpResponseRedirect("/api/login/")





def copy_ehrmodule_data(id, casename):
    """
    复制用例信息，默认插入到当前项目、莫夸
    :param id: str or int: 复制源
    :param name: str：新用例名称
    :return: ok or tips
    """
    try:
        ehrdata = ehr_module_employee.objects.get(id=id)
    except ObjectDoesNotExist:
        return '复制异常，请重试'
    if ehr_module_employee.objects.filter(casename=casename).count() > 0:
        return '名称重复了哦'
    print(ehrdata)
    ehrdata.id = None
    ehrdata.casename = casename
    ehrdata.save()
    logging.info('ehr模板（{casename}）添加成功'.format(casename=casename))
    return 'ok'


def del_ehrmodule_data(id):
    """
    根据id删除数据
    :param id: str or int: test or config index
    :return: ok or tips
    """
    try:
        obj = ehr_module_employee.objects.get(id=id)
        print(obj.__dict__)
        ehr_module_employee.objects.get(id=id).delete()
    except ObjectDoesNotExist:
        return '删除异常，请重试'
    logging.info('ehr数据已删除, id为{id}'.format(id=id))
    return 'ok'



def ehrdata_info_logic(sss=True, **kwargs):
    """
    信息逻辑处理
    :param type: boolean: True:默认新增模块
    :param kwargs: dict: mq工具信息
    :return:
    """
    if kwargs.get('casename') is '':
        return '模板名称不能为空'
    return add_ehrmodule_data(sss, **kwargs)


def add_ehrmodule_data(sss, **kwargs):
    """
    ehr模板信息落DB
    :param type: boolean: true: 新增， false: 更新
    :param kwargs: dict
    :return: ok or tips
    """

    ehrdata_opt = ehr_module_employee.objects
    casename = kwargs.get('casename')

    if sss:
        print("insert")
        if ehrdata_opt.filter(casename__exact=casename).count() < 1:
            try:
                ehrdata_opt.createerhmodule(**kwargs)
            except DataError:
                return '信息过长'
            except Exception as e:
                logging.error('信息添加异常：{kwargs}'.format(kwargs=kwargs))
                logging.error(str(e))
                return '添加失败，请重试'
            logger.info('添加成功：{kwargs}'.format(kwargs=kwargs))
        else:
            return '1该模板已存在，请重新命名'
    else:
        # print("update")
        # if casename != ehrdata_opt.get_casename('', type=False, id=kwargs.get('id'))  and ehrdata_opt.filter(casename__exact=casename).count() > 0:
        #     return '2该工具已存在，请重新命名'
        try:
            ehrdata_opt.update_ehrdate(kwargs.pop('id'), **kwargs)
        except DataError:
            return '信息过长'
        except Exception as e:
            logging.error('更新失败：{kwargs}'.format(kwargs=kwargs))
            logging.error(str(e))
            return '更新失败，请重试'
        logger.info('模板更新成功：{kwargs}'.format(kwargs=kwargs))
    return 'ok'






