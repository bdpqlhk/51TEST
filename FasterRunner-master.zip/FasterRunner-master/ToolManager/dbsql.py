# -*- coding: utf-8 -*-
import json
from qalib.MysqldbHelper import *
from settings.conf_db import  *
from django.http import HttpResponse
import logging
logger = logging.getLogger('HttpRunnerManager')


def sqlQuery(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        sql = received_json_data['sql']
        logger.info(sql)
        if sql == 'null':
            return HttpResponse("sql is null")
        else:
            db = DB(**ent_portal_test_db)
            fc = db.query(sql)
            i = 0
            data = {}
            for row in fc:
                data[i] = str(row[0])
                i += 1
            return HttpResponse(json.dumps(data))



def sqlModify(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        sql = received_json_data['sql']
        logger.info(sql)
        if sql == 'null':
            return HttpResponse("sql is null")
        else:
            db = DB(**ent_portal_test_db)
            db.modify(sql)
            return HttpResponse("succes")


def refundsql(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        sql = received_json_data['sql']
        print(sql)
        logger.info(sql)
        if sql == 'null':
            return HttpResponse("sql is null")
        else:
            test = DB(**refund_test_db)
            test.modify(sql)
            return HttpResponse("succes")






