# ***********************
# description：发送短信,封装sdk调用
# author：喻珩
# create time：2018.6.6
# ***********************

import logging
import json
from rest_framework.decorators import api_view
from django.http import JsonResponse,HttpResponse

from qalib.apiGateway import KongClient

logger = logging.getLogger("ToolManager")

import hashlib
import time
import json

# def get_time_now():
#     return time.strftime("%Y-%m-%d %H:%M:%S")
#
# def get_time_YmdHMS():
#     return time.strftime("%Y%m%d%H%M%S")
#
# def md5(src):
#     m = hashlib.md5()
#     m.update(src.encode("UTF-8"))
#     return m.hexdigest()
#
# def get_sms_sign_data(src):
#     return md5(str(src))
#
# key = "sunland"
# head = {
#     "productSystem":"个人中心",
#     "messageType":"EXTERNAL",
#     "groupNum":2,
#     "timing":get_time_YmdHMS(),
#     "operator":"yujinlong",
#     "createTime":get_time_now(),
#     "signData":""
# }
#
# head["signData"] = get_sms_sign_data("%s%s%s%s" % (head["productSystem"],head["messageType"],head["groupNum"],key))
#
# requestJson = {
#         "head":head,
#         "body":[
#             {
#                 "mobile":"15072388696",
#                 "message":"尊敬的学员陶盛龙您好，你的课程已经学习完成。",
#                 "sentType":"MESSAGE",
#                 "sendMarking":"【尚德机构】",
#                 "category1":"北京校",
#                 "category2":"自考",
#                 "category3":"行政管理本科"
#             },
#             {
#                 "mobile":"15072388696",
#                 "message":"尊敬的学员芦泷您好，你的课程已经学习完成。",
#                 "sentType":"MESSAGE",
#                 "sendMarking":"【尚德机构】",
#                 "category1":"北京校",
#                 "category2":"自考",
#                 "category3":"人力管理本科"
#             }
#         ]
#     }
@api_view(["POST"])
def send_sms(request):
    """
    发送短信，封装sdk调用
    uri：/tool/sms/send_sms
    :return:
    """
    jsonStr = request.body.decode("utf-8")
    apiClient = KongClient(
        kongBaseUrl="http://api-test.sunlands.com",
        appKey="userCenter",
        appSecret="Vr9SRJspfqo6Ygk6T3z2aRYxQy3eYfAe"
    )
    reqParams = {
        "requestJson": jsonStr
    }
    ret = apiClient.postForm("/smstest1/sms/sendSms", reqParams)
    return HttpResponse(str(ret.content, "utf8"))

def send_tpl_sms(request):
    """
    发送模板短信，封装sdk调用
    uri：/tool/sms/send_tpl_sms
    :return:
    """
    jsonStr = request.body.decode("utf-8")
    apiClient = KongClient(
        kongBaseUrl="http://api-test.sunlands.com",
        appKey="userCenter",
        appSecret="Vr9SRJspfqo6Ygk6T3z2aRYxQy3eYfAe"
    )
    reqParams = {
        "requestJson": jsonStr
    }
    ret = apiClient.postForm("/smstest1/sms/sendSms2", reqParams)
    return HttpResponse(str(ret.content, "utf8"))

# if __name__ == "__main__":
#     send_sms()