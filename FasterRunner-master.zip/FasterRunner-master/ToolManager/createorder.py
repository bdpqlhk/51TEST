# -*- coding: utf-8 -*-
import json
import re
from qalib.MysqldbHelper import *
from settings.conf_db import  *
import requests
import logging
import debugtalk
from django.http import HttpResponse
logger = logging.getLogger('HttpRunnerManager')
from qalib.MysqldbHelper import *
from settings.conf_db import  *

def createorder(request):
    if request.method == 'POST':
        received_json_data = json.loads(request.body)
        tradeurl = received_json_data['tradeurl']
        mobile = received_json_data['mobile']
        channelCode = received_json_data['channelCode']
        # totalAmount = received_json_data['totalAmount']
        insure = received_json_data['insure']
        orderDetails = ''
        if tradeurl == '':
            return HttpResponse("请输入tradeurl")
        elif mobile == '':
            return HttpResponse("请输入手机号码")
        elif channelCode == '请选择':
            return HttpResponse("请选择下单渠道")
        # elif totalAmount == '':
        #     return HttpResponse("请输入下单金额")
        # elif orderDetails == '':
        #     return HttpResponse("请输入orderDetails")
        else:
            stuId = selectstuId(mobile)
            if stuId == 'null':
                return HttpResponse("未查到手机号对应的学员id")
            else:
                timestamp = debugtalk.get_time_now()
                orderNumber = debugtalk.gen_order_number()
                if insure == '0':
                    totalAmount = int(1500)
                    orderDetails = [{"itemNo":"002180927000202","couponAmount":0,"insureAmount":0,"itemTitle":"无考试计划job【测试包】","itemPrice":1500}]
                if insure == '1':
                    orderDetails = [{"itemNo":"002180829000606", "couponAmount": 0, "insureAmount": 98, "itemTitle": "lhk汉语言本科（海尔）","itemPrice": 2980}]
                    totalAmount = (int(2980)+98)
                # if channelCode in ('OC_SCHOOL','OC_NEWDRAGNET'):
                #     totalAmount = int(2980)+int(98)
                #     orderDetails = [{"itemNo":"002180817000101", "couponAmount": 0, "insureAmount": 98, "itemTitle": "rgb产品包1205-A 百度","itemPrice": 2980}]
                bizContent= {"orderDetails":orderDetails,"provinceId": 4,"orderType":"NORMAL","totalAmount":totalAmount,"orderNumber":orderNumber,"stuId":str(stuId),"bizDate":timestamp,"payMethod":"天猫","sellerName":"zhouyahui","channelCode":channelCode,"notifyUrl":"http://172.16.116.136:7097/?stuId=1573531&itemNo=007180925000944&regionId=4&channelCode=OC_PORTAL&insuranceCheckedNo="}
                data = {"method": "createOrder", "channelCode": channelCode,"timestamp": timestamp, "version": "1.0", "sign": 123, "signType": "MD5", "bizContent":str(bizContent)}
                # 获取sign值
                print(data)
                requrl = "http://192.168.0.121:7321/platform/makesign/md5makesign"
                headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
                res = requests.post(requrl, data=data, headers=headerdata)
                ss = res.json()
                makesign = ss.get("sign")
                #创建订单
                orderdata = {"method": "createOrder", "channelCode": channelCode,"timestamp": timestamp, "version": "1.0", "sign": makesign, "signType": "MD5", "bizContent":str(bizContent)}
                tradeurl = "http://"+ tradeurl+ "/ent-trade-war/rest/trade/execute"
                order = requests.post(tradeurl, data=orderdata, headers=headerdata)
                print(bizContent)
                return HttpResponse(order.text)


def selectstuId(mobile):
    sql = "select id from t_user_info where mobile = %s LIMIT 1;"
    db = DB(**ent_portal_test_db)
    fc = db.query(sql,[mobile])
    if not fc:
        return "null"
    else:
        return (fc[0])[0]









