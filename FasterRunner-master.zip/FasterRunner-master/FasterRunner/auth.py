import time

from rest_framework import exceptions
from rest_framework.authentication import BaseAuthentication

from FasterRunner.settings import INVALID_TIME

# from fastuser import models
import requests
class Developer(object):
    pass

class Authenticator(BaseAuthentication):
    """
    账户鉴权认证 token
    """

    def authenticate(self, request):
        token = request.query_params.get("token", None)
        # print("testing1")
        # token = request.META.get("Access-Token",None)
        # data = {"jwtStr":token}
        # userinfo =requests.post('http://localhost:8888/validateJWT', data=data)
        # code = userinfo.json()['code']
        # print(userinfo.json())

        # obj = models.UserToken.objects.filter(token="425054633bd8f6c44c7076e03f8691c6").first()

        # if not obj:
        #     raise exceptions.AuthenticationFailed({
        #         "code": "9998",
        #         "msg": "用户未认证",
        #         "success": False
        #     })

        # if code != 0:
        #     raise exceptions.AuthenticationFailed({
        #         "code": "9998",
        #         "msg": "用户未认证",
        #         "success": False
        #     })

        # exp_time = int(userinfo.json()['data']['exp'])
        # current_time = int(time.time())
        # print(exp_time,current_time)
        # #
        # if exp_time < current_time:
        #     raise exceptions.AuthenticationFailed({
        #         "code": "9997",
        #         "msg": "登陆超时，请重新登陆",
        #         "success": False
        #     })


        # obj.token = "425054633bd8f6c44c7076e03f8691c6"
        # # obj.save()
        # print(obj.user, obj)
        obj = Developer()
        obj.token = "425054633bd8f6c44c7076e03f8691c6"
        obj.user = "zhouyahui"
        return obj.user, obj

    # def authenticate(self, request):
    #     token = request.query_params.get("token", None)
    #     obj = models.UserToken.objects.filter(token=token).first()
    #
    #     if not obj:
    #         raise exceptions.AuthenticationFailed({
    #             "code": "9998",
    #             "msg": "用户未认证",
    #             "success": False
    #         })
    #
    #     update_time = int(obj.update_time.timestamp())
    #     current_time = int(time.time())
    #
    #     if current_time - update_time >= INVALID_TIME:
    #         raise exceptions.AuthenticationFailed({
    #             "code": "9997",
    #             "msg": "登陆超时，请重新登陆",
    #             "success": False
    #         })
    #
    #     # valid update valid time
    #     obj.token = token
    #     obj.save()
    #
    #     return obj.user, obj

    def authenticate_header(self, request):
        return 'Auth Failed'
