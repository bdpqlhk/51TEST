from django.http import HttpResponse


def tool_process(request, **kwargs):
    app = kwargs.pop("app", None)
    module = kwargs.pop("module", None)
    function = kwargs.pop("function", None)
    id = kwargs.pop("id",None)

    if app == "tool":
        app = "ToolManager"

    try:
        app = __import__("%s.%s" % (app, module))
        view = getattr(app, module)
        fun = getattr(view, function)

        #执行相应module中函数
        result = fun(request, id) if id else fun(request)
    except (ImportError, AttributeError):
        raise

    return result


