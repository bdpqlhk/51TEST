# -*- coding: utf-8 -*-
import time
from har2case.core import HarParser

# 上传har文件
def uploadHarFile(request):
    fname = request.files.get('file')  # 获取上传的文件
    if fname:
        t = time.strftime('%Y%m%d%H%M%S')
        new_fname = r'upload/' + t + fname.filename
        fname.save(new_fname)  # 保存文件到指定路径
        return new_fname
    else:
        return '{"msg": "请上传文件！"}'



# har文件自动转换成case
def genJsonCase(file):
    output_file_type = "JSON"
    # har_source_file = "C:\\Users\\zhouyahui\\Desktop\\12.har"
    har_source_file = file
    try:
        list = HarParser(har_source_file)._make_testcase()
        return list
    except:
        return "ERROR"


