from django.apps import AppConfig


class FastrunnerConfig(AppConfig):
    name = 'fastrunner'
