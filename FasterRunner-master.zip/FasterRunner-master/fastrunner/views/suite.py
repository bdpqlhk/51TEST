from django.core.exceptions import ObjectDoesNotExist
from rest_framework.views import APIView
from rest_framework.viewsets import GenericViewSet
from fastrunner import models, serializers

from rest_framework.response import Response
from fastrunner.utils import response
from fastrunner.utils import prepare
import json


class TestCaseView(GenericViewSet):
    queryset = models.Case.objects
    serializer_class = serializers.CaseSerializer


    def Suitelist(self, request):
        """
        接口列表 {
            project: int,
            node: int
        }
        """
        received_json_data = json.loads(request.body)
        current_page = received_json_data['page']
        limit = int(received_json_data['limit'])
        current_page = int(current_page)
        start = (current_page - 1) * limit  # 10 20 (current_page-1)*10
        end = current_page * limit  # 20 30  current_page*10
        if ("projectId" not in received_json_data or received_json_data['projectId'] == ''):
            queryset = self.get_queryset().all().order_by('-update_time')[start:end]
            count = self.get_queryset().all().order_by('-update_time').count()
        else:
            project = received_json_data['projectId']
            if ("group" not in received_json_data or received_json_data['group'] == ''):
                queryset = self.get_queryset().filter(project__id=project).order_by('-update_time')[start:end]
                count = self.get_queryset().filter(project__id=project).order_by('-update_time').count()
            else:
                group = received_json_data['group']
                queryset = self.get_queryset().filter(project__id=project,group__id=group).order_by('-update_time')[start:end]
                count = self.get_queryset().filter(project__id=project,group__id=group).order_by('-update_time').count()
        serializer = self.get_serializer(queryset, many=True)
        responsedata = {"data": {"content": serializer.data, "totalElements": count}, "msg": ""}

        return Response(responsedata)

    def get(self, request):
        """
        查询指定CASE列表，不包含CASE STEP
        {
            "project": int,
            "node": int
        }
        """
        node = request.query_params["node"]
        project = request.query_params["project"]

        # update_time 降序排列
        queryset = self.get_queryset().filter(project__id=project, relation=node).order_by('-update_time')

        pagination_query = self.paginate_queryset(queryset)
        serializer = self.get_serializer(pagination_query, many=True)

        return self.get_paginated_response(serializer.data)

    # def copy(self, request, **kwargs):
    #     """
    #     pk int: test id
    #     {
    #         name: test name
    #         relation: int
    #         project: int
    #     }
    #     """
    #     pk = kwargs['pk']
    #
    #     if models.Case.objects.filter(**request.data).first():
    #         return Response(response.CASE_EXISTS)
    #
    #     case = models.Case.objects.get(id=pk)
    #     case.id = None
    #     case.name = request.data['name']
    #     case.save()
    #
    #     case_step = models.CaseStep.objects.filter(case__id=pk)
    #
    #     for step in case_step:
    #         step.id = None
    #         step.case = models.Case.objects.get(name=request.data['name'])
    #         step.save()
    #
    #     return Response(response.CASE_ADD_SUCCESS)

    def updateSuite(self, request):
        received_json_data = json.loads(request.body)
        try:
            project = received_json_data['project']
            group = received_json_data['group']
            casename = received_json_data['casename']
            step = received_json_data['step']
            config = received_json_data['config']
            responsible = received_json_data["responsible"]
        except KeyError:
            return Response(response.KEY_MISS)

        list = []
        for index in step:
            APIId = index["id"]
            list.append(APIId)
        Suite_body = {
            'name': casename,
            'group_id': group,
            'project_id': project,
            'APIStep': list,
            'config_id': config,
            'modifyBy': responsible
        }
        if  ("caseId" not in  received_json_data):
            if models.Case.objects.filter(project_id=project,group_id=group,name=casename).first():
                return Response(response.CASE_EXISTS)
            else:
                models.Case.objects.create(**Suite_body)
                return Response(response.CASE_ADD_SUCCESS)
        else:
            caseId = received_json_data['caseId']
            try:
                models.Case.objects.filter(id=caseId).update(**Suite_body)
            except ObjectDoesNotExist:
                return Response(response.SUITE_NOT_FOUND)
            return Response(response.CASE_ADD_SUCCESS)

    def AddSuiteForAPI(self, request):
        received_json_data = json.loads(request.body)
        try:
            project = received_json_data['projectId']
            group = received_json_data['group']
            casename = received_json_data['name']
            APIList = received_json_data["APIList"]
            config = received_json_data["config"]
            responsible = received_json_data["responsible"]
        except KeyError:
            return Response(response.KEY_MISS)
        IDS = []
        for I in APIList:
            ids = I["id"]
            IDS.append(ids)
        Suite_body = {
            'name': casename,
            'group_id': group,
            'project_id': project,
            'APIStep': IDS,
            'config_id': config,
            'responsible': responsible,
            'modifyBy': responsible
        }
        if models.Case.objects.filter(project_id=project,group_id=group,name=casename).first():
            return Response(response.CASE_EXISTS)
        else:
            models.Case.objects.create(**Suite_body)
            return Response(response.CASE_ADD_SUCCESS)

    def delete(self, request, **kwargs):
        """
        pk: test id delete single
        [{id:int}] delete batch
        """
        pk = kwargs.get('pk')

        try:
            if pk:
                prepare.case_end(pk)
            else:
                for content in request.data:
                    prepare.case_end(content['id'])

        except ObjectDoesNotExist:
            return Response(response.SYSTEM_ERROR)

        return Response(response.CASE_DELETE_SUCCESS)

    def getCaseStepByCaseId(self, request, **kwargs):
        """
        根据caseId返回API步骤
        """
        pk = kwargs['pk']

        Case = models.Case.objects.get(id=pk)
        APIListId = eval(Case.APIStep)
        project = models.Project.objects.get(id=Case.project_id)
        casegroup = models.Group.objects.get(id=Case.group_id)
        config = Case.config_id
        TestStepList = []
        for index in range(len(APIListId)):
            api = models.API.objects.get(id=APIListId[index])
            api_body = {
                'name': api.name,
                'body': api.body,
                'url': api.url,
                'method': api.method,
                'step': index,
                'id': APIListId[index]
            }
            TestStepList.append(api_body)
        responsedata = {
            'caseId': Case.id,
            'casename': Case.name,
            'step': TestStepList,
            'project': project.id,
            'group': casegroup.id,
            'APIListId': APIListId,
            'config': config
        }
        return Response(responsedata)


class CaseStepView(APIView):
#     """
#     测试用例step操作视图
#     """
#
#     def get(self, request, **kwargs):
#         """
#         返回用例集信息
#         """
#         pk = kwargs['pk']
#
#         queryset = models.CaseStep.objects.filter(case__id=pk).order_by('step')
#
#         serializer = serializers.CaseStepSerializer(instance=queryset, many=True)
#
#         return Response(serializer.data)

    def getCaseStepByCaseId(self, request, **kwargs):
        """
        根据caseId返回API步骤
        """
        pk = kwargs['pk']

        Case = models.Case.objects.get(id=pk)
        caseStepList = eval(Case.APIStep)
        TestStepList = []
        for index in range(len(caseStepList)):
            api = models.API.objects.get(id=caseStepList[index])
            body = eval(api.body)
            name = eval(api.name)
            url = eval(api.url)
            method = eval(api.method)
            kwargs = {"name": name,"body": body,"url": url,"method": method,"step": index,}
            TestStepList.append(kwargs)
        return Response(TestStepList)
