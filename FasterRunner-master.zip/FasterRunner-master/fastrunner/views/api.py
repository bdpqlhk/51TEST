from django.core.exceptions import ObjectDoesNotExist
from rest_framework.viewsets import GenericViewSet
from fastrunner import models, serializers
from rest_framework.response import Response
from fastrunner.utils import response
from fastrunner.utils.parser import Format, Parse
from django.db import DataError
import json


class APITemplateView(GenericViewSet):
    """
    API操作视图
    """
    serializer_class = serializers.APISerializer
    queryset = models.API.objects
    """使用默认分页器"""
    def APIlist(self, request):
        """
        接口列表 {
            project: int,
            node: int
        }
        """
        received_json_data = json.loads(request.body)
        current_page = received_json_data['page']
        limit = int(received_json_data['limit'])
        current_page = int(current_page)
        start = (current_page - 1) * limit  # 10 20 (current_page-1)*10
        end = current_page * limit  # 20 30  current_page*10
        global queryset
        global count
        if (("projectId" not in received_json_data or received_json_data['projectId'] == '') and ("name" not in received_json_data or received_json_data['name'] == '')):
            queryset = models.API.objects.all().order_by('-update_time')[start:end]
            count = models.API.objects.all().order_by('-update_time').count()
        elif(("projectId" not in received_json_data or received_json_data['projectId'] == '') and ("name" in received_json_data and received_json_data['name'] != '')):
            queryset = models.API.objects.filter(name__icontains=received_json_data['name']).order_by('-update_time')[start:end]
            count = models.API.objects.filter(name__icontains=received_json_data['name']).order_by('-update_time').count()
        elif ((received_json_data['projectId'] != '') and ("group" not in received_json_data or received_json_data['group'] == '') and ("name" not in received_json_data or received_json_data['name'] == '')):
            queryset = self.get_queryset().filter(project__id=received_json_data['projectId']).order_by('-update_time')[start:end]
            count = self.get_queryset().filter(project__id=received_json_data['projectId']).order_by('-update_time').count()
        elif ((received_json_data['projectId'] != '') and ("group" in received_json_data and received_json_data['group'] != '') and ("name" not in received_json_data or received_json_data['name'] == '')):
            queryset = self.get_queryset().filter(project__id=received_json_data['projectId'], group__id=received_json_data['group']).order_by('-update_time')[start:end]
            count = self.get_queryset().filter(project__id=received_json_data['projectId'], group__id=received_json_data['group']).order_by('-update_time').count()
        elif ((received_json_data['projectId'] != '') and ("group" not in received_json_data or received_json_data['group'] == '') and ("name" in received_json_data and received_json_data['name'] != '')):
            queryset = self.get_queryset().filter(project__id=received_json_data['projectId'], name__icontains=received_json_data['name']).order_by('-update_time')[start:end]
            count = self.get_queryset().filter(project__id=received_json_data['projectId'], name__icontains=received_json_data['name']).order_by('-update_time').count()
        elif((received_json_data['projectId'] != '') and (received_json_data['group'] != '') and (received_json_data['name'] != '')):
            project = received_json_data['projectId']
            group = received_json_data['group']
            name = received_json_data['name']
            queryset = self.get_queryset().filter(project__id=project, group__id=group, name__icontains=name).order_by('-update_time')[start:end]
            count = self.get_queryset().filter(project__id=project, group__id=group, name__icontains=name).order_by('-update_time').count()
        serializer = self.get_serializer(queryset, many=True)
        responsedata = {"data": {"content": serializer.data, "totalElements": count}, "msg": ""}
        return Response(responsedata)

    def CopyAPI(self, request):
        received_json_data = json.loads(request.body)
        ID = received_json_data['id']
        APIDATA = models.API.objects.get(id=ID)
        APIDATA.id = None
        APIDATA.name = received_json_data['name']
        if models.API.objects.filter(name=APIDATA.name,project_id=APIDATA.project_id,group_id=APIDATA.group_id).first() or received_json_data['name'] == '':
            return Response(response.API_EXISTS)
        else:
            APIDATA.save()
            return Response(response.API_ADD_SUCCESS)

    def list(self, request):
        """
        接口列表 {
            project: int,
            node: int
        }
        """

        node = request.query_params["node"]
        project = request.query_params["project"]

        queryset = self.get_queryset().filter(project__id=project, relation=node).order_by('-update_time')
        pagination_queryset = self.paginate_queryset(queryset)
        serializer = self.get_serializer(pagination_queryset, many=True)

        return self.get_paginated_response(serializer.data)

    def add(self, request):
        """
        新增一个接口
        """

        api = Format(request.data)
        api.parse()
        if 'project' not in api.__dict__:
            return Response({"code": "9999", "success": False, "msg": "请选择项目"})
        else:
            if 'group' not in api.__dict__:
                return Response({"code": "9999", "success": False, "msg": "请选择分组"})
            else:
                api_body = {
                    'name': api.name,
                    'body': api.testcase,
                    'url': api.url,
                    'method': api.method,
                    'project': models.Project.objects.get(id=api.project),
                    'group_id': api.group,
                    'config_id': api.config
                }
                try:
                    models.API.objects.create(**api_body)
                except DataError:
                    return Response(response.DATA_TO_LONG)

                return Response(response.API_ADD_SUCCESS)

    def update(self, request, **kwargs):
        """
        更新接口
        """
        pk = kwargs['pk']
        api = Format(request.data)
        api.parse()

        api_body = {
            'name': api.name,
            'body': api.testcase,
            'url': api.url,
            'method': api.method,
            'project_id': api.project,
            'group_id': api.group,
            'config_id': api.config,
            'modifyBy': request.data.pop('responsible')
        }

        try:
            models.API.objects.filter(id=pk).update(**api_body)
        except ObjectDoesNotExist:
            return Response(response.API_NOT_FOUND)

        return Response(response.API_UPDATE_SUCCESS)

    def delete(self, request, **kwargs):
        """
        删除一个接口 pk
        删除多个
        [{
            id:int
        }]
        """

        try:
            if kwargs.get('pk'):  # 单个删除
                models.API.objects.get(id=kwargs['pk']).delete()
            else:
                for content in request.data:
                    models.API.objects.get(id=content['id']).delete()

        except ObjectDoesNotExist:
            return Response(response.API_NOT_FOUND)

        return Response(response.API_DEL_SUCCESS)

    def single(self, request, **kwargs):
        """
        查询单个api，返回body信息
        """
        try:
            api = models.API.objects.get(id=kwargs['pk'])
        except ObjectDoesNotExist:
            return Response(response.API_NOT_FOUND)

        parse = Parse(eval(api.body))
        parse.parse_http()

        resp = {
            'id': api.id,
            'project': api.project_id,
            'group': api.group_id,
            'config': api.config_id,
            'body': parse.testcase,
            'success': True,
        }

        return Response(resp)


