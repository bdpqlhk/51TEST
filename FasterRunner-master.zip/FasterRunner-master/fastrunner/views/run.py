from rest_framework.decorators import api_view
from fastrunner.utils import loader
from rest_framework.response import Response
from fastrunner.utils.parser import Format
from fastrunner import models
import json
import time

"""运行方式
"""


@api_view(['POST'])
def run_api(request):
    """ run api by body and config
    """
    config = request.data.pop("config")
    api = Format(request.data)
    api.parse()
    if 'project' not in api.__dict__:
        data = {"code": "9999", "success": False, "msg": "请选择项目"}
        return Response(data)
    else:
        summary = loader.debug_api(api.testcase, config, api.project)
        return Response(summary)

@api_view(['POST'])
def run_api_mutl(request):
    received_json_data = json.loads(request.body)
    project = received_json_data['projectId']
    addSuite = request.data["addSuite"]
    back_async = received_json_data["asyncs"]
    name = received_json_data["name"]
    config = received_json_data["config"]
    APIList = received_json_data["APIList"]
    IDS = []
    for I in APIList:
        ids = I["id"]
        IDS.append(ids)
    testcase = []
    api = models.API.objects.filter(id__in = IDS).values('body')
    for content in api:
        testcase.append(eval(content['body']))
    if back_async:
        loader.async_debug_api(testcase, config, project, name)
        summary = loader.TEST_NOT_EXISTS
        summary["msg"] = "接口运行中，请稍后查看报告"
    else:
        summary = loader.debug_api(testcase, config, project)
    if addSuite:
        group = received_json_data["group"]


    return Response(summary)

@api_view(['GET'])
def run_api_pk(request, **kwargs):
    """run api by pk and config
    """
    api = models.API.objects.get(id=kwargs['pk'])
    testcase = eval(api.body)

    summary = loader.debug_api(testcase, request.query_params["config"], api.project.id)

    return Response(summary)


@api_view(['POST'])
def run_api_tree(request):
    """run api by tree
    {
        project: int
        relation: list
        config: int
        name: str
        async: bool
    }
    """
    # order by id default
    project = request.data['project']
    relation = request.data["relation"]
    back_async = request.data["async"]
    name = request.data["name"]
    config = request.data["config"]

    testcase = []
    for relation_id in relation:
        api = models.API.objects.filter(project__id=project, relation=relation_id).order_by('id').values('body')
        for content in api:
            testcase.append(eval(content['body']))
    if back_async:
        loader.async_debug_api(testcase, config, project, name)
        summary = loader.TEST_NOT_EXISTS
        summary["msg"] = "接口运行中，请稍后查看报告"
    else:
        summary = loader.debug_api(testcase, config, project)

    return Response(summary)


# @api_view(["POST"])
# def run_testsuite(request):
#     """debug testsuite
#     {
#         name: str,
#         config: int
#         body: dict
#     }
#     """
#     body = request.data["body"]
#
#     testcase_list = []
#
#     for test in body:
#         testcase_list.append(loader.load_test(test))
#
#     summary = loader.debug_api(testcase_list, request.data['config'], request.data["project"])
#
#     return Response(summary)


# @api_view(["POST"])
# def run_test(request):
#     """debug single test
#     {
#         config: int
#         body: dict
#     }
#     """
#
#     body = request.data["body"]
#     summary = loader.debug_api(loader.load_test(body), request.data["config"], request.data["project"])
#     return Response(summary)


@api_view(["GET"])
def run_testsuite_pk(request, **kwargs):
    """run testsuite by pk
        pk: int
        config: int
    """
    pk = kwargs["pk"]

    Case = models.Case.objects.get(id = pk)
    APIIds = eval(Case.APIStep)
    project = Case.project_id
    config = Case.config_id
    name = Case.name + time.strftime("%Y%m%d%H%M%S", time.localtime())

    test_list = models.API.objects.filter(id__in=APIIds).values("body")

    testcase_list = []
    testcase = []
    for content in test_list:
        testcase_list.append(eval(content["body"]))
    testcase.append(testcase_list)
    loader.async_debug_suite(testcase, config, project,name)
    summary = loader.TEST_NOT_EXISTS
    summary["msg"] = "用例运行中，请稍后查看报告"

    return Response(summary)



@api_view(['POST'])
def run_suite_group(request):
    project = request.data['project']
    group = request.data["group"]
    # back_async = request.data["async"]
    groupInfo = models.Group.objects.get(id=group)
    name = groupInfo.name
    # config = request.data["config"]
    if models.Case.objects.filter(group_id=group).first():
        SuiteList = models.Case.objects.filter(group_id=group).order_by('id').values('APIStep')
        config = models.Case.objects.filter(group_id=group).order_by('id').values('config_id').first()
        testcase = []
        for content in SuiteList:
            Ids = eval(content['APIStep'])
            test_list = models.API.objects.filter(id__in=Ids).values("body")
            testcase_list = []
            for content in test_list:
                testcase_list.append(eval(content["body"]))
            testcase.append(testcase_list)
        print(config)
        loader.async_debug_suite(testcase, config['config_id'], project, name)
        summary = loader.TEST_NOT_EXISTS
        summary["msg"] = "用例运行中，请稍后查看报告"
        return Response(summary)
    else:
        TEST_NOT_EXISTS = {
            "code": "0102",
            "status": False,
            "msg": "请确认该分组下是否有用例集"
        }
        return Response(TEST_NOT_EXISTS)



