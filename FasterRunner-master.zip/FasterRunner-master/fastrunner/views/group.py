import json

from django.core.exceptions import ObjectDoesNotExist
from rest_framework.views import APIView
from rest_framework.viewsets import GenericViewSet
from fastrunner import models, serializers
from FasterRunner import pagination
from rest_framework.response import Response
from fastrunner.utils import response
from fastrunner.utils import prepare
from fastrunner.utils.runner import DebugCode
from fastrunner.utils.tree import get_tree_max_id, get_file_size


class Group(GenericViewSet):
    """
    树形结构操作
    """
    serializer_class = serializers.GroupSerializer

    def list(self, request):
        """
        查询项目信息        """
        received_json_data = json.loads(request.body)
        current_page = received_json_data['page']
        limit = int(received_json_data['limit'])
        current_page = int(current_page)
        start = (current_page - 1) * limit  # 10 20 (current_page-1)*10
        end = current_page * limit  # 20 30  current_page*10
        if ("projectId" not in  received_json_data or received_json_data['projectId'] == ''):
            GroupList = models.Group.objects.all().order_by('-id')[start:end]
            count = models.Group.objects.all().order_by('-id').count()
        else:
            projectId = received_json_data['projectId']
            if ("type" not in received_json_data or received_json_data['type'] == ''):
                GroupList = models.Group.objects.filter(project__id=projectId).order_by('-id')[start:end]
                count = models.Group.objects.filter(project__id=projectId).order_by('-id').count()
            else:
                type = received_json_data['type']
                GroupList = models.Group.objects.filter(project__id=projectId,type=type).order_by('-id')[start:end]
                count = models.Group.objects.filter(project__id=projectId,type=type).order_by('-id').count()
        serializer = self.get_serializer(GroupList, many=True)
        responsedata = {"data": {"content":serializer.data,"totalPages":int(count/10)+1,"totalElements":count},"msg": ""}
        return Response(responsedata)

    def add(self, request):
        """
        添加分组
        """



        name = request.data["name"]
        projectId = request.data["projectId"]
        type = request.data["type"]
        responsible = request.data["responsible"]


        if models.Group.objects.filter(project__id=projectId,type=type,name=name).first():
            response.GROUP_EXISTS["name"] = name
            return Response(response.GROUP_EXISTS)
        """
        反序列化
        """
        group_body = {
            'name': name,
            'type': type,
            'project': projectId,
            'responsible': responsible
        }

        serializer = serializers.GroupSerializer(data=group_body)

        if serializer.is_valid():
            serializer.save()
            # project = models.Project.objects.get(name=name)
            # prepare.project_init(project)
            return Response(response.GROUP_ADD_SUCCESS)

        else:
            return Response(response.SYSTEM_ERROR)

    def update(self, request):
        """
        编辑分组
        """
        name = request.data["name"]
        projectId = request.data["projectId"]
        type = request.data["type"]

        try:
            group = models.Group.objects.get(id=request.data['id'])
        except (KeyError, ObjectDoesNotExist):
            return Response(response.SYSTEM_ERROR)

        if request.data['name'] != group.name:
            if models.Group.objects.filter(project__id=projectId,type=type,name=name).first():
                return Response(response.PROJECT_EXISTS)

        # 调用save方法update_time字段才会自动更新
        group.name = name
        group.project_id = projectId
        group.type = type
        group.save()

        return Response(response.GROUP_UPDATE_SUCCESS)

    def delete(self, request):
        """
        删除分组
        """
        try:
            group = models.Group.objects.get(id=request.data['id'])
            if prepare.group_delete_check(group):
                group.delete()
                # prepare.group_end(group)
                return Response(response.PROJECT_DELETE_SUCCESS)
            else:
                return Response(response.DELETE_GROUP_FAIL)
        except ObjectDoesNotExist:
            return Response(response.SYSTEM_ERROR)