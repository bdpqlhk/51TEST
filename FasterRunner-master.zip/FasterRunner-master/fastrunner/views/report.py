from rest_framework.renderers import TemplateHTMLRenderer
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet

from FasterRunner import pagination
from fastrunner import models, serializers
import json


class ReportView(GenericViewSet):
    """
    报告视图
    """
    # # renderer_classes = [TemplateHTMLRenderer]
    # authentication_classes = ()
    # queryset = models.Report.objects.all().order_by('-update_time')
    serializer_class = serializers.ReportSerializer
    # pagination_class = pagination.MyPageNumberPagination

    def ReportList(self, request):
        reportList = ''
        received_json_data = json.loads(request.body)
        current_page = received_json_data['page']
        limit = int(received_json_data['limit'])
        current_page = int(current_page)
        start = (current_page - 1) * limit  # 10 20 (current_page-1)*10
        end = current_page * limit  # 20 30  current_page*10
        if ("projectId" not in  received_json_data or received_json_data['projectId'] == ''):
            reportList = models.Report.objects.all().order_by('-update_time')[start:end]
            count = models.Report.objects.all().count()
        else:
            projectId = received_json_data['projectId']
            reportList = models.Report.objects.filter(project_id=projectId).order_by('-update_time')[start:end]
            count = models.Report.objects.filter(project_id=projectId).count()
        serializer = self.get_serializer(reportList, many=True)
        responsedata = {
        "data": {"content":serializer.data,"totalPages":int(count/10)+1,"totalElements":count},"msg": ""}
        return Response(responsedata)



    def delete(self, request):
        """删除报告
        """
        pass

    def look(self, request, **kwargs):
        """查看报告
        """
        pk = kwargs["pk"]
        summary = models.Report.objects.get(id=pk).summary
        return Response(json.loads(summary))

    def download(self, request, **kwargs):
        """下载报告
        """
        pass

    def SavaReport(self, request):
        report = self.get_queryset()
        page_report = self.paginate_queryset(report)
        serializer = self.get_serializer(page_report, many=True)
        return self.get_paginated_response(serializer.data)
