"""FasterRunner URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.urls import path
from fastrunner.views import project, api, config, database, run, suite, report,group

urlpatterns = [
    # 项目相关接口地址
    path('project/', project.ProjectView.as_view({
        "get": "list",
        "post": "add",
        "patch": "update",
        "delete": "delete"
    })),
    path('project/<int:pk>/', project.ProjectView.as_view({"get": "single"})),

    path('projectlist/', project.ProjectView.as_view({
        "post": "projectlist"
    })),

    # 数据库相关接口地址
    path('database/', database.DataBaseView.as_view({
        "get": "list",
        "post": "create",
    })),
    path('database/<int:pk>/', database.DataBaseView.as_view({
        'patch': 'partial_update',
        'delete': 'destroy'
    })),

    # debugtalk.py相关接口地址
    path('debugtalk/<int:pk>/', project.DebugTalkView.as_view({"get": "debugtalk"})),
    path('debugtalk/', project.DebugTalkView.as_view({
        "patch": "update",
        "post": "run"
    })),

    # 二叉树接口地址
    path('tree/<int:pk>/', project.TreeView.as_view()),

    # group相关接口地址
    path('group/', group.Group.as_view({
        "post": "add",
        "patch": "update",
        "delete": "delete"
    })),
    path('group/<int:pk>/', group.Group.as_view({"get": "single"})),

    path('grouplist/', group.Group.as_view({
        "post": "list"
    })),


    # 文件上传 修改 删除接口地址
    path('file/', project.FileView.as_view()),

    # api接口模板地址
    path('api/', api.APITemplateView.as_view({
        "post": "add",
        "get": "list"
    })),
    path('apilist/', api.APITemplateView.as_view({
        "post": "APIlist"
    })),
    path('CopyAPI/', api.APITemplateView.as_view({
        "post": "CopyAPI"
    })),

    path('api/<int:pk>/', api.APITemplateView.as_view({
        "delete": "delete",
        "get": "single",
        "patch": "update"
    })),

    # test接口地址
    path('test/', suite.TestCaseView.as_view({
        "get": "get",
        "post": "updateSuite",
        "delete": "delete"
    })),
    path('getCaseStepByCaseId/<int:pk>/', suite.TestCaseView.as_view({
        "get": "getCaseStepByCaseId"
    })),

    path('Suitelist/', suite.TestCaseView.as_view({
        "post": "Suitelist"
    })),

    path('AddSuiteForAPI/', suite.TestCaseView.as_view({
        "post": "AddSuiteForAPI"
    })),

    path('test/<int:pk>/', suite.TestCaseView.as_view({
        "delete": "delete",
        "post": "copy"
    })),

    # path('teststep/<int:pk>/', suite.CaseStepView.as_view()),

    # config接口地址
    path('config/', config.ConfigView.as_view({
        "post": "add",
        "delete": "delete"
    })),
    path('CopyConfig/', config.ConfigView.as_view({
        "post": "CopyConfig"
    })),
    path('configlist/', config.ConfigView.as_view({
        "post": "Configlist"
    })),
    path('configlist/<int:pk>/', config.ConfigView.as_view({
        "get": "all"
    })),

    path('config/<int:pk>/', config.ConfigView.as_view({
        "post": "copy",
        "delete": "delete",
        "patch": "update",
        "get": "single"
    })),

    # run api
    path('run_api_pk/<int:pk>/', run.run_api_pk),
    path('run_api_mutl/', run.run_api_mutl),
    path('run_api_tree/', run.run_api_tree),
    path('run_api/', run.run_api),

    # run testsuite
    # path('run_testsuite/', run.run_testsuite),
    # path('run_test/', run.run_test),
    path('run_testsuite_pk/<int:pk>/', run.run_testsuite_pk),
    path('run_suite_group/', run.run_suite_group),

    # 报告列表
    path('ReportList/', report.ReportView.as_view({
        "post": "ReportList"
    })),

    path('report/<int:pk>/', report.ReportView.as_view({"get": "look"}))

]
