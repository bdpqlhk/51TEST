# -*- coding: utf-8 -*-

# ***********************
# description：用例中调用的函数放在此文件中
# author：喻珩
# create time：2018.5.16
# ***********************
import random
import time
import string
import requests
import os
from urllib.parse import unquote
from qalib.MysqldbHelper import *
# from qalib.dragnet import DragnetDB
from settings.conf_db import  *
from settings.config import baseurl,envconfig
from urllib import request
from http import cookiejar
import json
import hashlib
import datetime
from typing import AnyStr
from qalib.CAS import *
import time
import hashlib

# from qalib.sms import SmsDB


# DRAGNETDB = DragnetDB()

def get_base_url():
    return baseurl["dragnet"] + "growth"

def get_env(module):
    """
    :param module:模块名
    :return: 环境信息，host:port
    """
    return envconfig[module]

# def get_opportunity_id_by_oid(oid):
#     # 先urldecode，然后获取oid
#     oid = unquote(oid).split("%")[0]
#     try:
#         opportunity_id = DRAGNETDB.get_opportunity_id_by_oid(int(oid))
#     except ValueError:
#         raise Exception("oid format error")
#     return opportunity_id
#
#
# def delete_evaluate_consultant_opportunity_record_by_oid(oid):
#     opportunity_id = get_opportunity_id_by_oid(oid)
#     DRAGNETDB.delete_evaluate_consultant_opportunity_record_by_opportunity_id(opportunity_id)
#
# def delete_drag_comment_sms_by_oid(oid):
#     opportunity_id = get_opportunity_id_by_oid(oid)
#     DRAGNETDB.delete_drag_comment_sms_by_oid(opportunity_id)
#
# def get_smsid_by_callid(callid):
#     """
#     根据callid获取smsid
#     """
#     time.sleep(8)
#     return DRAGNETDB.get_smsid_by_callid(callid)

def get_random_chartid(prefix="kf_9740_ISME9754_"):
    """
    生成随机chartId，新建机会时需要该id
    """
    return prefix + str(random.randint(1000000000000, 9999999999999))

def get_random_callid():
    """
    :return:返回随机callid
    """
    return random.randint(100000000000000000000000000000000, 999999999999999999999999999999999)

def get_random_cellphone_number():
    """
    :return:获取随机电话号码，新建机会时会用到
    """
    prefixlist = ["130", "139", "150", "151", "152", "153", "155", "158", "159"]
    cellphone = prefixlist[random.randint(0 ,8)] + str(random.randint(10000000, 99999999))
    return cellphone

def get_new_opportuniy_by_stu_phone(cellphone):
    stuid = DRAGNETDB.get_student_id_by_cellphone(cellphone)
    opportunity_id = DRAGNETDB.get_opportunity_id_by_student_id(stuid)
    return opportunity_id




def get_time_now():
    return time.strftime("%Y-%m-%d %H:%M:%S")

def get_time_YmdHMS():
    return time.strftime("%Y%m%d%H%M%S")

def get_timestamp_ms():
    return int(time.time()*1000)

def gen_order_number():
    t = time.time()
    return "autotest" + str(int(round(t * 1000)))

def replace(data):
    a = data.replace('"','')
    ss = a.replace( '&quot;', '"')
    return ss

def to_str(param):
    return str(param, "utf8")


def convert_n_bytes(n, b):
    bits = b*8
    return (n + 2**(bits-1)) % 2**bits - 2**(bits-1)

def convert_4_bytes(n):
    return convert_n_bytes(n, 4)

def getHashCode(s):
    h = 0
    n = len(s)
    for i, c in enumerate(s):
        h = h + ord(c)*31**(n-1-i)
    return convert_4_bytes(h)

def wait_30s():
    time.sleep(30)

def get_random_str_with_prefix(prefix="None-"):
    """
    生成指定前缀+随机数字的字符串
    """
    return prefix + str(random.randint(1000000000000, 9999999999999))

def get_random_str(str_type, length=10):
    if str_type == "letter":
        chars = string.ascii_letters
    elif str_type == "upper":
        chars = string.ascii_uppercase
    elif str_type == "lower":
        chars = string.ascii_lowercase
    elif str_type == "number":
        chars = string.digits
    else:
        chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


def activitiComplainTimesTrigger(sleep_time=20):
    requrl = "http://172.16.116.136:7070/job/j_spring_security_check"
    headerdata1 = {"Content-Type": "application/x-www-form-urlencoded"}
    data = 'j_username=zhanghongwei&j_password=zhanghw1005.&j_office=&j_product='
    with requests.Session() as s:
        res = s.post(requrl, data=data, headers=headerdata1,allow_redirects=False)
    ss = res.headers['set-cookie']
    headerdata2 = {"cookie": ss}
    r = requests.get('http://172.16.116.136:7070/job/layout/runNow.action?triggerName=activitiComplainTimesTrigger&targetBizDate=&officeId=',headers = headerdata2,allow_redirects=False)
    time.sleep(sleep_time)



def loginconfigcenter():
    requrl = "http://172.16.140.76:7388/api/user/login"
    headerdata1 = {"Content-Type": "application/x-www-form-urlencoded"}
    data = 'account=zhouyahui&password=0417WOW'
    with requests.Session() as s:
        res = s.post(requrl, data=data, headers=headerdata1,allow_redirects=False)
    ss = res.headers['set-cookie']
    print(ss)
    return ss





# 已经转移到项目的debugtalk里了
# def jobcookie():
#     requrl = "http://172.16.116.136:9091/cas/login?service=http%3A%2F%2F172.16.116.136%3A6061%2FworkOrder-web%2FentOrder%2Frepeat.do%3Forigin-page%3Dhttp%253A%252F%252F172.16.116.136%253A6061%252F%2523%252Findex"
#     headerdata1 = {"Content-Type": "application/x-www-form-urlencoded"}
#     data = 'username=cs-lichao&password=123456&execution=2dedf8e9-c4cb-4247-ab4d-93adfe856091_ZXlKaGJHY2lPaUpJVXpVeE1pSjkuVjBwYVVucEpVbkZ6ZFZkTFFqRk5kMlF6YkV3eU1teHZVeXRwTmtOQ01XeEpVbWhKT1ZObmVuVXZNM2x1VjA1dGEyVmhUR3cxVEhWTVJVZzRaSEpGYVVkdlExVmtRMUJzUm5SdE1HSlFZMUpoVm5sTWVrRXJjVWR0V0RKS2NsQmhjak5WTDNWSVFuWlBLMG8zYkUwNFpFWktlbTlwVDJOVFZubGtaMGw2VW5oNlIzVTVlWEV5ZUcxak9UUkZhak40UTBkUk9IazBhMUZ3UTFGMFNtRm5WbmhYYjFwWE4yeDJiVWd6TTNJNVUwRXdieTlhY0dwRk9HbFZiV3dyZEdKWmRIazFSMnMzY2toRGRUaEdUbFJwUWtwSmJWQjVaM0JUVXpSaldrUnhURW9yVkcxcmRuRnpiM1pKU1VvMk1GUTVNRTVyWjNWaFdYSjFVWFVyTm5sMFlURXpRMWMzUWtSaVFuWmxNVXBXUTNad2QzcHhaMVZoZFVzMVJYZFBkVUZIVmpSS1IwcE1TRzVVWTI5U2VucHlUV2t6WjBkNk5UUnVZMVJ5YjI4MWJXWXdkRTlUZFhSbFMwVlJiRVZVTDB4elMyeElSWGR2Y2xVMU1FSXdabmhaYTIxS2FYRnNOMUI0VWxVelVVNURkR0pFT1dFemEydHlhRFl4T0doM01FbzVZMXBOU210Qk0wcDNPVEEwUlc1VFRVOVBjMVpIWVZWT09EUm1laTlXTkRabU5tNUVkMVF3YW5oMFZFNXFWWHBYTWxWd09WSnpUVkpOTHl0QmJYcEZVM2xQUzJ0UVptRmxSazltU1U5NFpVODNPREIyUTJWblJGSnNkVGRaY25CTU5GQlVOR3h3UVhZMFJtNUhWMjlHU1dka1ZsVjBSM0ExU0dKQ1VrVlBUV2hwYUdaeU5XNVFZME4zVVdreWFqUkdVVlo0V0doc1FXUm5NMFJSWkVGUWRrNWxkRm8zVTB4MFYwNXFNazFHYXpCRlJYaERXVGREYzI5SU1WQjNjVU12T0dJMFVVZEZUekY0WVdwS1EwcHhRV3RLWjFKVmNVMHhZMGxoVkN0TVEyMXBWek0wYTBaeWMza3lTRFJQWTFOUlJXUjZVRGRxUzJGa1pHVmpVbmhHT0RNNFRGRXJla3BXU0hGc1R5OURTMFEwTjBka2VEQllNV1poVkdaMU4yazFVMGRpVjFGclNsUjZWa3c0TDA5bU0yczRTVzlYY0daaFFYbG9TRVl2V25CU2VGTTVXalZ0WTBSeVFqRkpSMk40TkZoTFRHUlJWbUoxYjJFMFQwUnJlR2RNYkhaWlNrZEpiazlFVlM5Q05rVk9kSEZXV0M5UGNVcFRTV2MwYjFJdlJsUkJabVZETjNBelJ6aFhObGx3VkVGU01qWjVUekZrU1ZSM1VtTkJWakl4VGpBMU9XVlRObkpLYUhWRVdVdElUbTVhVDAwelJuWlZkbVZEUmxwUFZsTlRUV3N5ZVVSSmJIcGlOVGxHU21WUFlrSnlaR2N6ZFhKUFpqUjJhMnA0Vm05V1ZFeE5RVXBXT0VJME5HdDBOVEpNZGs5UEwzWlRVVTgzUWxSaU16SnZSMUZEVEZVd1owUXpXR3RHVTNFNFdVNXZkMGRJWVZsV1VuTTBhVlppYmxKNE5rOUhRVFJzUWxKVE5sUnZkWFJ6Vm14MGVIRkJiVlUwUkRGRFdVaFpSR1kwZURBemNIWklkRTkwUm1kV2MwNVdOVGRZWjI4NE0xUmhhMVJwVkV0blVHMHZSamNyUjI0NFJFNTJVR3h1TmtNME5UQjZWRmhRTVdWQ2FrMUtjbVp1ZVc1SFlrTm9kSFJqTlVkaWVHeGlTMUZ2TDNKdmFTOVlMMnRSUm1sSFMzTkdha1JUWkVKSVNFWkVhelZ5VG10eGNVVk1lRU54UzBSVlJFVjNSelU0TkU0elFtMVRObk56VVhWVGFYcFdlV1ZhVld4RFVITjBkM3BYTURNek1IWmpORkZ2VTBaT00zWjVSR0k1WW5ORE5WZHZVbUphUTNwRWJVSXpZbVJSVTA1bFdVRXpjekpOWjFWaUx6UmxSaXRIU0Vzd2FXMXlhR2gzY1RWdFFWZFJaMDVVYUdFdmVFYzJUMmsxTDJsc1dYbzRhbU00U2xGeFpucEROVGhSUzIxM2JGVjRPSFYxUnpNM1YwVmxPWE5rVDJoTE1WVkJaamszU1VOUGRGRXhRMWhaWjFCS1lVcEtWamdyUkUwNFRrWnNiM2RES3poVWRXcG1aR3hUWWpkb1JFVndNVUZLTVd0S1QwMUpkbFZ4U0ZaeGNpOW9OMjVhY1VWRksyTXhZWGMyWkVWcWFGcHpLMHRHVUZWU2FFSnpUelZSS3k5blRXWm9ka3RvWVhkUlQxcFJjV2x0ZFhoM1prRkZkRWQwYTFvMVkwcHBXakJzYVVkNVRtUnJSMGx4VVVaeFRsWjZRbkpPUVdzMGJYYzRXVTFKTW1FNVNsbHJORVJQVWtOMmVHOHpkemhGTXpVd1dqRk5WakZIT0ZreWMxaGtOMU5OTWtKbldEWmlORmc1TDBOM2FVaE5kRTB2VHpkM01UUnFSMmh2Um5VM2RUVldhaTlDU1ZGYWMwUTVkMWw1VVROYWMyeHllR1pHZEhsU1NFVlRiVFpVVkcxNFUwOXBkRmhOT1hGVFJtSnJiRUZqU0ZJd09WQkdhREZYYld0VlRubEdUR2x2VEhaV1ZWZENOMmxLY0RaNk5IVjBRbGhtZWtKbWNHRTVkVkp5VTNaNmRGQTBUR1l3TWs5NVZGaHJXVU5RTDI5Rk1GaGtRVUZoVUZCMlZrRllOMjRyZFVSdFNtTjVWazAwV21aYUwwaHBLMFJYYUhBdlN6SXdTMDlYYUhwV1NYbzVUMDVUSzNoQ1JHbERUMlZtVEdGbFJYbzFNM1o1VG10RVRtNDJPVmhhVEZZNWFGbFRNVGd6VkdSVGRIRjZOemxEWmxSeU5HMVdORzluUW1Wa2FtTXlOVXh3VUdGMGFtcE9hakJwVEhKYVIyVlRTRkJLYkhCdmJWRkZjWFY0TkUxWFdISTFNRWc0TURsTWNXeHBObTVzUzFOdVJXc3pUMDQ1YTNReGVYVlFVbTl6VnpWbmNsTnFkRE5FWmpKSGF6SnllVEJJWW1Sb1dUWXJjRVpJYkcweWRUYzFkWEZxYUhsSU5XWXdNRFo1Wm1wS2VqUm5aMVZKTjJkSk1VdHNjbmw2Wmpsd00xZEdOR3huUmtreWEwMDFXbGxuTkRsMWNGbGxla0pUTjJRdlZWbE5TRGhXVVc1d2VVWjNWM1ZPVFhvMGVVTXlZM0YwU25oTllVTndkR3RIVm5relIxcHZXblJrYzBJeVQwazVXV3RvVVVnMVpqY3hjMVZtWXpRcmNUWmhSM1JWUlVwRVVqVjRRVkF2V21sRFpVOVZVM050VjB0a1lYTm9ka1p2U2l0bWFVdGFZM0UzTTB0VlNtZFNabWxQTkhKMFMzVjBiVWRMSzA1bVRGWmlNU3RYU0hkNk5XTlFlRlF4Um01bFZFYzJSV0V4WVVOcFFUVlVVV2xTZW1kR1ZrNVdWM0ZZVkRSdlMwRjJaM1pZZVhSSFpHOTFSV2h0VmtsUlNtNHlaRk56WmpKM1dFUlZOWGc0YkhwcmRtTklTemd6Vkc1dU9VaFJkalZDZWpkalNqSTVOM0ZJVGpCd2NETmxSVzV3ZW5KaGEyUjBkakJ1Wnk5bmVXdE9la0Z1UjBsa2RGRnFkekJwUjJ0aWVqaHRNR0ZqVHpsNFUwOXhNV1paTjJ0WVltaDBUbVJRWkN0NWRFeFVhVzVLWjFkblpteDVZblZRVVU1ck1HVlJjelJZT1hKNU5XZEdNMk5OVG14aE5FazNka3BSYzNkVlprWjBSWE0zT1dndmNXNTFTelJqZG05M1IzcFVPRUo2ZEhkNEwwWklUV2hTY1ZnM1kwZ3pWMDV6UTFCVVdGcGlhVmRVYVd0VWRHMDJUMFV3ZWtWaVFVcE1UMXBVTlVsSE15OUdaSFEwVm5SWFZrSnNLM0pCU0ZCTk1qWTBlVmhJVmpkaFRrZHpjelZ6YmxkclRUbDNTbFpuVGxScGMwWXdWazVpVkhGRVdUVnFlVWMwU21GRGVXaFVZVEIwT0dscmJFbDVNREpQT1hwQmRITjJUREJNWlM4MU0zUjJNR1JHT0c5ek5UZzJNM0ZGWmtsb1NVWkdjbnAwV0cxdWJHUk5PRGxFVnpWUFowVllZVnB4U25rcmVVcDNaRXRsTlc4NE9VbGlUMUVyTTBKQlNXOWhSbU40YUU1R2Eyc3ZTMVJPUVdkR1RGVnZTRW93VUVKaWF6bGlUMUpQY3pkNk1FVlFUMVZpTmxnMlRUUlRSVEpFY0dGRWVrOXNXSGhCUFEuY2RhQ0l0cWNsckNQdV9CNzJqNFh3Ti1UQm1QaDFTMmxDQmNzV0czRURodjdMZGZBb0dVOFhGZ2s4X250MzBlYW11OGhnS0pVeWlvMnFvX3N5Q2t3OWc%3D&_eventId=submit'
#     with requests.Session() as s:
#         res = s.post(requrl, data=data, headers=headerdata1,allow_redirects=False)
#     Cookie = res.headers['Set-Cookie']
#     location = res.headers['Location']
#     headerdata2 = {"Cookie": Cookie}
#     print(Cookie)
#     print(location)
#     with requests.Session() as t:
#         res = t.get(location, allow_redirects=False)
#     ss = res.headers['Set-Cookie']
#     print(ss)
#     return ss




def AgreeRefund(orderid):
    # 查询refundTaskId
    header = {"Content-Type": "application/x-www-form-urlencoded"}
    subOrderNumble = orderid+"_1"
    # 查询refundTaskId
    selectrefundTaskIdurl = "http://172.16.117.225:7075/refund/refund/queryRefundTaskList"
    selectrefundTaskIddata = "merchantCode=OC_TRADE&subOrderNumber="+subOrderNumble
    selectrefundTask = requests.post(selectrefundTaskIdurl, data=selectrefundTaskIddata, headers=header)
    print("查询refundTaskId："+ selectrefundTask.text)
    refundTaskId = selectrefundTask.json()["data"]["refundTasks"][0]["refundTaskId"]
    print(refundTaskId)
    # # 退费确认
    AgreeRefundurl = "http://172.16.117.225:7075/refund/refund/batchAgreeRefundTask"
    AgreeRefunddata = "refundTaskIds="+ str(refundTaskId)+"&merchantCode=OC_TRADE&operator=autotester"
    AgreeRefund = requests.post(AgreeRefundurl, data=AgreeRefunddata, headers=header)
    print("确认退费:"+AgreeRefund.text)
    return selectrefundTask.text




def workorder_db_sqlQuery(sql):
    db = DB(**workorder_db)
    fc = db.query(sql)
    for row in fc:
        print(json.dumps(row[0]))
        return json.dumps(row[0])


def ent_portal_sqlQuery(sql):
    print(sql)
    db = DB(**ent_portal_test_db)
    fc = db.query(sql)
    for row in fc:
        ss = row[0]
        return json.dumps(ss)


def execute_sql():
    """执行指定目录下的.sql文件"""
    filename = os.getcwd() + '/Sql/'
    if os.path.exists(filename) == False:
        filename = '/data/sdtools/sdTestManager/Sql'
    db = DB(**configcenter_test_db)
    conn, cur = db.conn_mysql()
    os.chdir(filename)
    print(conn, cur)
    for each in os.listdir("."):
        if "config.sql" in each:
            with open(each, "r", encoding="utf-8") as f:
                sql_list = f.read().split(';')[:-1]  # sql文件最后一行加上;
                sql_list = [x.replace('\n', ' ') if '\n' in x else x for x in sql_list]
                for sql_item in sql_list:
                    print("_____分割线——————————————————")
                    print (sql_item)
                    try:
                       cur.execute(sql_item)
                    except Exception as e:
                        logging.error(e)
    cur.close()
    conn.close()
    return 'succes'

def get_MD5(s):
    md=hashlib.md5()
    md.update(s.encode('utf-8'))
    md5 = md.hexdigest()
    return md5

def get_value_in_JSONSTR(jsonstr:AnyStr,key1='data',key2='id'):
    try:
        key1_value = (json.loads(jsonstr))[key1]
        if isinstance(key1_value,list):
            key1_value = key1_value[0]
        key2_value = (json.loads(key1_value))[key2]
    except Exception as e:
        raise e
    return key2_value

def gongdan_cookie(username='cs-lichao',url=''):
    if not url:
        # url = 'http://172.16.116.136:6061/#/index/workflowManage/list'
        url = "http://172.16.116.136:6061/workOrder-web/entOrder/repeat.do?origin-page=http://172.16.116.136:6061/#/index/workflowManage/list"
    return PR_Login_with_url(username,url)

def PR_Login_with_kesu(username='cs-lichao',url=''):
    if (not url) or (url ==''):
        # url = 'http://172.16.116.136:6061/#/index/workflowManage/list'
        url = "http://172.16.116.136:7079/cw/common/tologin?origin-page=http://172.16.116.136:7079/order/complainList"
    return PR_Login_with_url(username,url)



def get_order_center_response(customerComplainId):
    url = 'http://172.16.116.136:7079/cw/complain/changeComplainRetention?id='+str(customerComplainId)
    header = {'Cookie':PR_Login_with_kesu()}
    r = requests.get(url, headers= header,allow_redirects=False)
    return r

def get_order_center_location(customerComplainId):
    r = get_order_center_response(customerComplainId)
    location = r.headers['Location']
    print('----Get location: {}'.format(r.headers))
    return location.replace('http://','')

def get_order_center_token(customerComplainId):
    location = get_order_center_location(customerComplainId)
    token = location.split('token=')[1]
    return token


def ListToStr(list):
    ss =",".join('%s' % id for id in list)
    print(ss)
    return ss

def ent_portal_SqlModify(sql):
    print(sql)
    db = DB(**ent_portal_test_db)
    db.modify(sql)
    return 'success'

def IntToStr(int_number):
    res = str(int_number)
    return res

def ent_portal_sqlQuery_to_string(sql):
    print(sql)
    db = DB(**ent_portal_test_db)
    fc = db.query(sql)
    for row in fc:
        ss = row[0]
        return str(json.dumps(ss))

def subtraction(minuend, *args):
    s = sum(args)
    return minuend - s

def current_day():
    s= datetime.datetime.now().strftime('%Y-%m-%d')
    return s

def IntToFloatToStr(i):
    f = float(i)
    s = str(f)
    return s

def IntToFloat(i):
    f = float(i)
    return f

def wait_time(i):
    time.sleep(i)

def get_op_cookie():
    op_url = 'http://42.62.70.203:7068/op/j_spring_security_check?j_username=zhouzhijun&j_password=7064943a&j_src_flag=OPERATION'
    header_data1 =\
        {"Content-Type":"application/x-www-form-urlencoded","rmbMe":"false","Referer": "http://42.62.70.203:7068/op/dist/index.html",
         "Origin": "http://42.62.70.203:7068","Host": "42.62.70.203:7068"}   # "rmbMe":False,

    r = requests.post(op_url,headers = header_data1,  allow_redirects=False)
    cookie = r.headers['Set-Cookie']
    cookie = cookie.replace(' Path=/op/; HttpOnly','')
    return cookie

def PR_Login_with_finance(username='cs-lichao',url=''):
    if (not url) or (url ==''):
        url = "http://172.16.117.225:7045/finops/login??originPage=http://172.16.117.225/finops-web/"
    ori_cookie = PR_Login_with_url(username,url)
    cookie = ori_cookie.replace('; Path=/finops; HttpOnly','')
    print('----Finance cookie2: {}'.format(cookie))

    # continue log for finance
    location1 = 'http://172.16.117.225:7045/finops/login;jsessionid=' + cookie +  '??originPage=http://172.16.117.225/finops-web/'
    header1 = {'Referer':'http://172.16.117.225/finops-web/', 'Content-Type':'application/x-www-form-urlencoded'}
    rs1 = requests.get(location1,headers=header1,allow_redirects=False)

    location2 = 'http://172.16.117.225/finops/refund/queryUserInfoAndLogOutUrl?'
    header2 = {'Cookie': cookie}
    rs2 = requests.get(location2, headers = header2)

    return cookie

def transfer_byte_to_json(byte_json):
    if isinstance(byte_json,dict):
        return byte_json
    js = json.loads(byte_json)
    return js

def get_values_by_keys(key_list,byte_json,index=0):
    """
    Step1. Transfer json or json in byte_str, to dict,
    Step2. get the value in key_list
    e.g. get_values_by_keys(['data','datalist'],s)
    :param key_list:
    :param byte_json:
    :param index:
    :return:
    """
    js = transfer_byte_to_json(byte_json)
    for i in key_list:
        if isinstance(js,str):
            js = transfer_byte_to_json(js)
        if isinstance(js,list):
            js=js[index]
        js = js[i]
    return js

def get_value_in_path(byte_json):
    return get_values_by_keys(['data','dataList','status'],byte_json)



def md5(src):
    m = hashlib.md5()
    m.update(src.encode("UTF-8"))
    return m.hexdigest()


def get_sms_sign_data(src):
    return md5(str(src))


# def check_table_s_sms_message(mobile, create_time):
#     smsDB = SmsDB()
#     condition = {
#         "mobile": mobile,
#         "create_time": create_time
#     }
#     return smsDB.get_table_s_sms_message_num_by_condition(**condition)