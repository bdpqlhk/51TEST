from django.apps import AppConfig


class FasttaskConfig(AppConfig):
    name = 'fasttask'
