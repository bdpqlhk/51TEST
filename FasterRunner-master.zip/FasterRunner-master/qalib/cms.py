# ***********************
# description：短信平台lib
# author：喻珩
# create time：2018.6.20
# ***********************
from settings.conf_db import dbconfig
from qalib.MysqldbHelper import DB

class CmsDB(DB):
    """
    cms db类
    """

    def __init__(self):
        super(CmsDB, self).__init__(
            DB_HOST=dbconfig["cms"]["host"],
            DB_PORT=dbconfig["cms"]["port"],
            DB_USER=dbconfig["cms"]["user"],
            DB_PWD=dbconfig["cms"]["password"],
            DB_NAME=dbconfig["cms"]["name"]
        )

    def delete_cms_message_definition_by_id(self, id):
        sql = "delete from cms_message_definition where id={id};".format(id=id)
        self.modify(sql)
