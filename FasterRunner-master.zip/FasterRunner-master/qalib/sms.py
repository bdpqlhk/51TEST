# ***********************
# description：短信平台lib
# author：喻珩
# create time：2018.6.20
# ***********************
from settings.conf_db import dbconfig
from qalib.MysqldbHelper import DB

import datetime
import time

class SmsDB(DB):
    """
    短信平台db类
    """

    def __init__(self):
        super(SmsDB, self).__init__(
            DB_HOST=dbconfig["sms"]["host"],
            DB_PORT=dbconfig["sms"]["port"],
            DB_USER=dbconfig["sms"]["user"],
            DB_PWD=dbconfig["sms"]["password"],
            DB_NAME=dbconfig["sms"]["name"]
        )

    def get_table_s_sms_message_num_by_condition(self, **kwargs):
        """
        根据条件获取s_sms_message_xxx表记录数
        :param mobile: 手机号码
        :param create_time: 创建时间，格式为：时间戳（毫秒，如1529464162211）或"Y%-m%-d% H%-M%-S%"(2018-06-20 11:09:22)
        :return:
        """
        # 插入数据偶尔比较慢，先sleep 5秒
        time.sleep(5)
        year = datetime.datetime.now().year
        month = datetime.datetime.now().month
        month = '0'+str(month) if month < 10 else str(month)
        tableName = 's_sms_message_%s_%s' % (year, month)
        sql = "select count(*) from {table} where ".format(table=tableName)
        condition = '1=1 '
        for k, v in kwargs.items():
            if k == "create_time":
                if (isinstance(v, str) and v.isdigit()) or isinstance(v, int):
                    v = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(round(int(v)*1.0/1000)))
            condition += ' and {k}="{v}" '.format(k=k, v=v)
        sql += condition
        result = self.query(sql)
        return result[0][0]

# if __name__ == "__main__":
#     sms = SmsDB()
#     condition={'mobile': '13091935633', 'create_time': 1529473491263}
#     print(sms.get_table_s_sms_message_num_by_condition(**condition))