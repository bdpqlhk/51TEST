# -*- coding: utf-8 -*-
# ***********************
# description：新天网lib
# author：喻珩
# create time：2018.5.16
# ***********************

from settings.conf_db import dbconfig
from qalib.MysqldbHelper import DB


class DragnetDB(DB):
    """
    新天网db类
    """

    def __init__(self):
        super(DragnetDB, self).__init__(
            DB_HOST=dbconfig["dragnet"]["host"],
            DB_PORT=dbconfig["dragnet"]["port"],
            DB_USER=dbconfig["dragnet"]["user"],
            DB_PWD=dbconfig["dragnet"]["password"],
            DB_NAME=dbconfig["dragnet"]["name"]
        )

    def get_opportunity_id_by_oid(self, oid):
        sql = "select opportunity_id from drag_opportunity_cms_encoder_log where id = %s;" % oid
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("drag_opportunity_cms_encoder_log data error: one oid must match only one opportunity id")

        opportunity_id = result[0][0]
        return opportunity_id

    def delete_evaluate_consultant_opportunity_record_by_opportunity_id(self, opportunity_id):
        sql = "delete from evaluate_consultant_opportunity_record where opportunity_id = %s;" % opportunity_id
        self.modify(sql)

    def delete_drag_comment_sms_by_oid(self, opportunity_id):
        sql = "delete from drag_comment_sms where opportunity_id = %s;" % opportunity_id
        self.modify(sql)

    def get_smsid_by_callid(self,callid):
        sql = 'select id from drag_comment_sms where call_id = "%s";'% callid
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("drag_comment_sms callid error: one id must match only one call id")

        smsid = result[0][0]
        return smsid

    def get_student_id_by_cellphone(self, cellphone):
        sql = 'select id from drag_student where mobile = "%s";' % cellphone
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("drag_student error: one mobile phone number must match only one student id")

        stuid = result[0][0]
        return stuid

    def get_opportunity_id_by_student_id(self,student_id):
        sql = 'select id from drag_opportunity where student_id = "%s";' % student_id
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("drag_opportunity error: one student id must match only one opportunity id")

        opportunity_id = result[0][0]
        return opportunity_id

    def delete_drag_student(self, phone):
        sql = 'delete from drag_student where phone = "%s" or mobile = "%s" or mobile_bak = "%s" or phone = "%s" or qq = "%s" or wechat = "%s";' % (phone, phone, phone, phone, phone, phone)
        self.modify(sql)


