# -*- coding: utf-8 -*-
# ***********************
# description：评价体系lib
# author：喻珩
# create time：2018.8.13
# ***********************

from settings.conf_db import dbconfig
from qalib.MysqldbHelper import DB


class CommentDB(DB):
    """
    评价体系db类
    """

    def __init__(self):
        super(CommentDB, self).__init__(
            DB_HOST=dbconfig["comment"]["host"],
            DB_PORT=dbconfig["comment"]["port"],
            DB_USER=dbconfig["comment"]["user"],
            DB_PWD=dbconfig["comment"]["password"],
            DB_NAME=dbconfig["comment"]["name"]
        )

    def get_smsid_by_callid(self,callid):
        sql = 'select id from comment_call_triger_record where call_record_id = "%s";'% callid
        print(sql)
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("drag_comment_sms callid error: one id must match only one call id")

        print(result)
        smsid = result[0][0]
        return smsid

if __name__ == "__main__":
    cdb = CommentDB()
    cdb.get_smsid_by_callid(577403569516717400613865495990821)