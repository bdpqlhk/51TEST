# -*- encoding:utf8 -*-
'''
@author: zhouyahui
@data: 2018-10-26

'''

import requests
from lxml import etree

casurl = "http://172.16.116.136:9091/cas/login"
# service url

# 产品维护系统
prurl = "http://172.16.140.50:7645/pr/login/tologin?origin-page=http://172.16.140.50:7645/"

# 工单系统
WorkUrl = "http://172.16.116.136:6061/workOrder-web/entOrder/repeat.do?origin-page=http://172.16.116.136:6061/#/index/workflowManage/list"

def PR_Login(username,url):
    headerdata = {"Cookie": CAS_Cookie(username)}
    with requests.Session() as s:
          res = s.get(casurl+'?service='+url, headers=headerdata,allow_redirects=False)
    location = res.headers['Location']
    with requests.Session() as t:
         res2 = t.get(location, allow_redirects=False)
    ss = res2.headers['Set-Cookie']
    return ss


def CAS_Cookie(username):
    execution = Execution()
    data = "username="+username+"&password=12&execution="+execution+"&_eventId=submit"
    headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
    res = requests.post(casurl,data = data,headers=headerdata)
    Cookie = res.headers['Set-Cookie']
    return Cookie


def Execution():
    res = requests.get(casurl)
    tree = etree.HTML(res.content)
    execution = tree.xpath('//input[@name="execution"]/@value')[0]
    return execution


