# ***********************
# description：ehr lib
# author：喻珩
# create time：2018.5.16
# ***********************

from settings.conf_db import ehr_test_db
from qalib.MysqldbHelper import DB


class EhrDB(DB):
    """
    EHR db类
    """

    def __init__(self):
        super(EhrDB, self).__init__(
            DB_HOST=ehr_test_db["DB_HOST"],
            DB_PORT=ehr_test_db["DB_PORT"],
            DB_USER=ehr_test_db["DB_USER"],
            DB_PWD=ehr_test_db["DB_PWD"],
            DB_NAME=ehr_test_db["DB_NAME"]
        )

    def get_instance_id_by_status_and_emp_id(self, status, employee_id):
        if status not in [0,1,2] or not isinstance(employee_id, int):
            raise Exception("input status or employee_id is invalid")
        #获取请假结束时间最大的记录
        sql = 'select instanceId from t_work_attendance_leaves where status = "%s" and employee_id="%s" order by end_dt desc limit 1;' % (status, employee_id)
        result = self.query(sql)
        if len(result) == 0:
            raise Exception("no record meet condition")

        instance_id = result[0][0]
        return instance_id

    def get_employee_id_by_tel(self, tel):
        sql = 'SELECT employee_id from t_employee_base_info WHERE tel = "%s";' % tel
        result = self.query(sql)
        if len(result) > 1:
            raise Exception("t_employee_base_info record error: one tel must match only one employee id")

        employee_id = result[0][0]
        return employee_id
