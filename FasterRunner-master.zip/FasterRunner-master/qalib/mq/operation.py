# ***********************
# description：mqtool页面操作相关函数
# author：喻珩
# create time：2018.6.6
# ***********************
import logging

from django.db import DataError
from django.core.exceptions import ObjectDoesNotExist

from ApiManager.models import MqToolInfo

logger = logging.getLogger("ToolManager")

def add_mqtool_data(type, **kwargs):
    """
    mq工具信息落DB
    :param type: boolean: true: 新增， false: 更新
    :param kwargs: dict
    :return: ok or tips
    """

    mqtool_opt = MqToolInfo.objects
    belong_project = kwargs.get('belong_project')
    mqtool_name = kwargs.get('name')

    if type:
        if mqtool_opt.filter(name__exact=mqtool_name).count() < 1:
            try:
                mqtool_opt.insert_mqtool(**kwargs)
            except DataError:
                return 'mq工具信息过长'
            except Exception as e:
                logging.error('mq工具信息添加异常：{kwargs}'.format(kwargs=kwargs))
                logging.error(str(e))
                return '添加失败，请重试'
            logger.info('mq工具添加成功：{kwargs}'.format(kwargs=kwargs))
        else:
            return '该工具已存在，请重新命名'
    else:
        if mqtool_name != mqtool_opt.get_mqtool_name('', type=False, id=kwargs.get('id')) \
                and mqtool_opt.filter(belong_project__exact=belong_project) \
                        .filter(name__exact=mqtool_name).count() > 0:
            return '该工具已存在，请重新命名'
        try:
            mqtool_opt.update_mqtool(kwargs.pop('id'), **kwargs)
        except DataError:
            return 'mq工具信息过长'
        except Exception:
            logging.error('更新失败：{kwargs}'.format(kwargs=kwargs))
            return '更新失败，请重试'
        logger.info('mq工具更新成功：{kwargs}'.format(kwargs=kwargs))
    return 'ok'


def del_mqtool_data(id):
    """
    根据工具id删除数据
    :param id: str or int: test or config index
    :return: ok or tips
    """
    try:
        obj = MqToolInfo.objects.get(id=id)
        print(obj.__dict__)
        MqToolInfo.objects.get(id=id).delete()
    except ObjectDoesNotExist:
        return '删除异常，请重试'
    logging.info('mq工具已删除, id为{id}'.format(id=id))
    return 'ok'


def copy_mqtool_data(id, name):
    """
    复制用例信息，默认插入到当前项目、莫夸
    :param id: str or int: 复制源
    :param name: str：新用例名称
    :return: ok or tips
    """
    try:
        mqtool = MqToolInfo.objects.get(id=id)
    except ObjectDoesNotExist:
        return '复制异常，请重试'
    if MqToolInfo.objects.filter(name=name).count() > 0:
        return 'mq工具名称重复了哦'
    mqtool.id = None
    mqtool.name = name
    mqtool.save()
    logging.info('mq工具（{name}）添加成功'.format(name=name))
    return 'ok'


