#-*- coding:utf-8 -*-
# ***********************
# description：rocketmq lib函数
# author：喻珩
# create time：2018.6.5
# ***********************

import requests
import json
import random

from qalib.mq import mqproxy_pb2

def get_key():
    return str(random.randint(0,99999999999999))

class SendCommonMsgClient(object):
    """
    普通消息发送client
    """
    def __init__(self, topic, tag, appid, secretkey, producerid, topictype=1, mode=1):
        """
        :param topic:
        :param tag:
        :param appid:
        :param secretkey:
        :param producerid:
        :param topictype: 1表示普通消息，2表示顺序消息
        :param mode: 1表示同步，2表示异步
        """
        self.send_request = mqproxy_pb2.SendMsgRequest()
        self.send_request.topic = topic
        self.send_request.appid = appid
        self.send_request.securt = secretkey
        self.send_request.producerid = producerid
        self.send_request.topic_type = topictype
        self.send_request.mode = mode
        self.msg2send = self.send_request.msgs.add()
        self.msg2send.tag = tag

    def send(self,mqurl,msgcontent):
        client = requests.session()
        headers = {
            "Content-Type": "application/octet-stream",
            "Connection": "keep-alive"
        }

        #msgkey必须唯一，可以根据该参数到运维平台上查询消息
        self.msg2send.key = get_key()
        self.msg2send.content = msgcontent
        #shardingkey顺序消息必须指定的参数，需要保证有序的几条消息的shardingkey相同，普通消息可以不指定
        # msg2send.shardingkey = sendcount
        params = self.send_request.SerializeToString()

        respond = client.post(mqurl, data=params, timeout=5000, headers=headers)
        send_respond = mqproxy_pb2.SendMsgRespond()
        send_respond.ParseFromString(respond.content)
        return {
            "errcode": str(send_respond.ret),
            "content": str(respond.content),
            "msgkey": self.msg2send.key,
            "msgparam": str(params),
            "paramsize": str(len(params))
        }


# if __name__ == "__main__":
#     commonMsgClient = SendCommonMsgClient(
#         topic="DEV_TID_TOPIC_ENT_PACKAGE_INSURANCE",
#         tag="*",
#         appid="DEV_AID_ENT",
#         secretkey="GaHBBOlaL3y2Ux1OF7juu8HZMftO0kK9",
#         producerid="PRODUCER_COMMON")
#
#     content = [{"packageId":1822720,"hasInsurance":"True","premium":198.0}]
#
#     print(commonMsgClient.send("http://172.16.116.47:6002/sendmsg", json.dumps(content)))
