#-*- coding:utf-8 -*-
# ***********************
# description：mq工具页面依赖的lib函数
# author：喻珩
# create time：2018.6.6
# ***********************

from qalib.mq.operation import add_mqtool_data

def mqtool_info_logic(type=True, **kwargs):
    """
    添加mq工具信息逻辑处理
    :param type: boolean: True:默认新增模块
    :param kwargs: dict: mq工具信息
    :return:
    """
    if kwargs.get('name') is '':
        return 'mq工具名称不能为空'
    if kwargs.get('belong_project') == '请选择':
        return '请选择项目，没有请先添加哦'
    if kwargs.get('author') is '':
        return '创建者不能为空'
    if kwargs.get('msg_topic') is '':
        return 'topic不能为空'
    if kwargs.get('topic_tag') is '':
        return 'topic tag不能为空'
    if kwargs.get('appid') is '':
        return 'appid不能为空'
    if kwargs.get('secretkey') is '':
        return 'secretkey不能为空'
    if kwargs.get('producerid') is '':
        return 'producerid不能为空'
    if kwargs.get('proxyurl') is '':
        return 'proxyurl不能为空'
    if kwargs.get('msg_body') is '':
        return 'msgbody不能为空'
    return add_mqtool_data(type, **kwargs)