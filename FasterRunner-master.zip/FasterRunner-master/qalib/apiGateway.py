# ***********************
# description：api gateway sdk
# author：喻珩
# create time：2018.6.14
# ***********************

import requests
import hashlib
import base64
import hmac
import time
import urllib.parse

from settings.conf_db import dbconfig
from qalib.MysqldbHelper import DB
from qalib.common import get_gmt_time, url_encoder

class KongClient(object):
    """
    api网关客户端基类
    """
    HTTP_GET = "GET"
    HTTP_POST = "POST"
    HTTP_PUT = "PUT"
    HTTP_DELETE = "DELETE"
    HTTP_PATCH = "PATCH"
    HTTP_OPTION = "OPTION"
    HTTP_HEAD = "HEAD"
    DATE_HEADER_NAME = "x-date"
    AUTH_HEADER_NAME = "proxy-authorization"
    BODY_DIGEST_HEADER_NAME = "digest"
    AUTH_HEADER_VALUE_FMT = "hmac username=\"%s\", algorithm=\"hmac-sha256\", headers=\"%s\", signature=\"%s\""

    def __init__(self, kongBaseUrl, appKey, appSecret):
        self.kongBaseUrl = kongBaseUrl
        self.appKey = appKey
        self.appSecret = appSecret


    def _doRequest(self, uri, method, body=None, params=None, headers=None):
        if headers == None:
            headers = {}
        elif headers != None and not isinstance(headers,dict):
            raise Exception("headers type error")
        # locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
        headers[self.DATE_HEADER_NAME] = get_gmt_time()
        headersStr = self.DATE_HEADER_NAME
        signatureStr = self.DATE_HEADER_NAME + ": " + headers[self.DATE_HEADER_NAME]

        if body:
            #使用"SHA-256"算法对body字符串进行摘要，对摘要结果进行Base64操作，然后拼接成如下字符串：SHA-256={前面Base64操作得到的字符串}
            headers[self.BODY_DIGEST_HEADER_NAME] = "SHA-256=" + str(base64.b64encode(hashlib.sha256(body.encode()).digest()),'utf-8')
            headersStr = headersStr + " " + self.BODY_DIGEST_HEADER_NAME
            signatureStr = signatureStr + "\n" + self.BODY_DIGEST_HEADER_NAME + ": " + headers[self.BODY_DIGEST_HEADER_NAME]

        #使用 “HMAC_SHA_256”算法，以网关上创建的应用的appSecret作为key，对上一步构造出的字符串进行hmac加密，并对加密结果进行Base64
        signature = str(base64.b64encode(hmac.new(self.appSecret.encode(), signatureStr.encode(), digestmod=hashlib.sha256).digest()), "utf-8")
        headers[self.AUTH_HEADER_NAME] = self.AUTH_HEADER_VALUE_FMT % (self.appKey, headersStr, signature)

        httpClient = requests.session()
        url = self.kongBaseUrl + uri
        if method == "GET":
            rsp = httpClient.get(url, headers=headers, params=params)
        elif method == "POST":
            rsp = httpClient.post(url, data=body, headers=headers)
        elif method == "PUT":
            rsp = httpClient.put(url, data=body, headers=headers)
        elif method == "PATCH":
            rsp = httpClient.patch(url, data=body, headers=headers)
        elif method == "DELETE":
            rsp = httpClient.delete(url, headers=headers, params=params)
        elif method == "OPTION":
            rsp = httpClient.options(url, headers=headers)
        elif method == "HEAD":
            rsp = httpClient.head(url, headers=headers)
        else:
            raise Exception("Method error")

        # print(locale.getlocale())
        return rsp

    def get(self, uri, params=None):
        return self._doRequest(uri, self.HTTP_GET, params=params)

    def postForm(self, uri, dic_body):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }
        body = urllib.parse.unquote(url_encoder(dic_body))
        # for k,v in params.items():
        #     body = k+"="+v
        return self._doRequest(uri, self.HTTP_POST, body, headers=headers)

    def postTextBody(self, uri, body):
        return self._doRequest(uri, self.HTTP_POST, body=body)

    def postMultipartForm(self,uri, dic_body):
        headers = {
            "Content-Type": "multipart/form-data"
        }
        pass

    def patchForm(self, uri, dic_body):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }
        body = urllib.parse.unquote(url_encoder(dic_body))
        return self._doRequest(uri, self.HTTP_PATCH, body, headers=headers)

    def patchTextBody(self, uri, body):
        return self._doRequest(uri, self.HTTP_PATCH, body=body)

    def putForm(self, uri, dic_body):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }
        body = urllib.parse.unquote(url_encoder(dic_body))
        return self._doRequest(uri, self.HTTP_PUT, body, headers=headers)

    def putTextBody(self, uri, body):
        return self._doRequest(uri, self.HTTP_PUT, body=body)

    def deleteForm(self, uri, dic_body):
        headers = {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        }
        body = urllib.parse.unquote(url_encoder(dic_body))
        return self._doRequest(uri, self.HTTP_DELETE, body, headers=headers)

    def deleteTextBody(self, uri, body):
        return self._doRequest(uri, self.HTTP_DELETE, body=body)


class ApiGatewayAdminDB(DB):
    """
    api网关管理端DB类
    """

    def __init__(self):
        super(ApiGatewayAdminDB, self).__init__(
            DB_HOST=dbconfig["apiGatewayAdmin"]["host"],
            DB_PORT=dbconfig["apiGatewayAdmin"]["port"],
            DB_USER=dbconfig["apiGatewayAdmin"]["user"],
            DB_PWD=dbconfig["apiGatewayAdmin"]["password"],
            DB_NAME=dbconfig["apiGatewayAdmin"]["name"]
        )

    def get_a_group_by_audit_status_and_user(self, status, user):
        sql = 'select id,name from user_group where name like "yuhengGroupTestCanDelete%%" and username="%s" and audit_status="%s";' % (user, status)
        result = self.query(sql)
        if len(result) == 0:
            return None
        else:
            id_name = "%s,%s" % (result[0][0], result[0][1])
            return id_name

    def insert_group(self, name, status, user='yuheng'):
        time_now = time.strftime("%Y-%m-%d %H:%M:%S")
        create_time = last_update_time = time_now
        sql_insert_group = '''INSERT into user_group(`name`,`remark`,`audit_status`,`username`,`create_time`,`last_update_time`) 
                VALUES('%s','test',%s,'%s','%s','%s');''' % (name, status, user, create_time, last_update_time)
        self.modify(sql_insert_group)
        sql_query_group_id = 'select id from user_group where name = "%s";' % name
        result = self.query(sql_query_group_id)
        group_id = result[0][0]
        sql_insert_group_share = '''INSERT into group_share(`group_id`,`operator`,`create_time`) 
                VALUES(%s,'%s','%s');''' % (group_id, user, create_time)
        self.modify(sql_insert_group_share)

    def get_a_consume_by_audit_status_and_user(self, status, user):
        sql = 'select id, app_name from consumer where app_name like "yuheng_app_testCanDelete%%" and username="%s" and audit_status="%s";' % (user, status)
        result = self.query(sql)
        if len(result) == 0:
            return None
        else:
            id_name = "%s,%s" % (result[0][0], result[0][1])
            return id_name

    def insert_consume(self, app_name, status, user='yuheng'):
        time_now = time.strftime("%Y-%m-%d %H:%M:%S")
        create_time = time_now
        sql_insert_consumer = '''INSERT into consumer(`app_name`,`remark`,`audit_status`,`username`,`create_time`) 
                VALUES('%s','test',%s,'%s','%s');''' % (app_name, status, user, create_time)
        self.modify(sql_insert_consumer)
        sql_query_consumer_id = 'select id from consumer where app_name = "%s";' % app_name
        result = self.query(sql_query_consumer_id)
        consumer_id = result[0][0]
        sql_insert_consumer_share = '''INSERT into consumer_share(`consumer_id`,`operator`,`create_time`) 
                        VALUES(%s,'%s','%s');''' % (consumer_id, user, create_time)
        self.modify(sql_insert_consumer_share)

# if __name__ == '__main__':
#     kong_client = KongClient(
#         kongBaseUrl="http://api-test.sunlands.com",
#             appKey="yuheng_app_test",
#         appSecret="6p1pSkCMYH6QnqlplxRlIniCQrTRcubX"
#     )
#
#     # result = kong_client.postForm("/yuhengTest1/yuhengPostTest", dic_body={})
#     # print(result.content)
#     # result = kong_client.postTestBody("/yuhengTest1/yuhengPostTest", body="")
#     # print(result.content)
#
#     result = kong_client.putForm("/yuhengTest1/yuhengPutTest", dic_body={})
#     print(result.content)
#     result = kong_client.putTextBody("/yuhengTest1/yuhengPutTest", body="")
#     print(result.content)
#     result = kong_client.deleteForm("/yuhengTest1/yuhengDeleteTest", dic_body={})
#     print(result.content)
#     result = kong_client.deleteTextBody("/yuhengTest1/yuhengDeleteTest", body="")
#     print(result.content)
