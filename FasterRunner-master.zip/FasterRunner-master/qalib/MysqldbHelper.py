# -*- encoding:utf8 -*-
'''
@author: crazyant.net
@version: 2013-10-22

封装的mysql常用函数
'''


import MySQLdb
import logging


class DB(object):
    def __init__(self, DB_HOST, DB_PORT, DB_USER, DB_PWD, DB_NAME):
        self.DB_HOST = DB_HOST
        self.DB_PORT = DB_PORT
        self.DB_USER = DB_USER
        self.DB_PWD = DB_PWD
        self.DB_NAME = DB_NAME


    def getConnection(self):
        return MySQLdb.Connect(
            host=self.DB_HOST,  # 设置MYSQL地址
            port=self.DB_PORT,  # 设置端口号
            user=self.DB_USER,  # 设置用户名
            passwd=self.DB_PWD,  # 设置密码
            db=self.DB_NAME,  # 数据库名
            charset='utf8'  # 设置编码
        )

    def query(self, sqlString,params=None):
        conn = self.getConnection()
        cursor = conn.cursor()
        cursor.execute(sqlString,params)
        returnData = cursor.fetchall()
        cursor.close()
        conn.close()
        return returnData

    def update(self, sqlString,params=None):
        conn = self.getConnection()
        try:
            cursor = conn.cursor()
            # 执行sql语句
            cursor.execute(sqlString,params)
            # 提交到数据库执行
            conn.commit()
            cursor.close()
        except:
            # Rollback in case there is any error
            conn.rollback()
        # 关闭数据库连接
        conn.close()

    def insert(self, sqlString,params=None):
        conn = self.getConnection()
        try:
                cursor = conn.cursor()
                # 执行sql语句
                cursor.execute(sqlString,params)
                # 提交到数据库执行
                conn.commit()
                cursor.close()
        except:
                conn.rollback()
        # 关闭数据库连接
        conn.close()

    def modify(self, sqlString, params=None):
        """
        :param sqlString:需要执行的插入、修改、删除操作的sql语句
        """
        conn = self.getConnection()
        try:
            cursor = conn.cursor()
            print(sqlString)
            cursor.execute(sqlString, params)
            conn.commit()
        except:
            conn.rollback()
            raise Exception("run sql failed, sql is:%s" % sqlString)
        conn.close()


    def conn_mysql(self,params=None):
            conn = self.getConnection()
            try:
                cur = conn.cursor()
                return conn, cur
            except Exception as e:
                conn.rollback()
                logging.info('Connect to mysql Error!')
                logging.error(e)
            conn.close()