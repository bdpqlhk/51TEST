import time
import random
import json
# import urllib2

def paramcommon(param):
    if param in ('None', ''):
       return None
    elif param.find("年"):
        c = param.replace("年", "-")
        d = c.replace("月", "-")
        e = d.replace("日","")
        return e

def idcard_generator():
    """ 随机生成新的18为身份证号码 """
    ARR = (7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2)
    LAST = ('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2')
    t = time.localtime()[0]
    x = '%02d%02d%02d%04d%02d%02d%03d' % (
    random.randint(10, 99), random.randint(1, 99), random.randint(1, 99), random.randint(t - 80, t - 18),
    random.randint(1, 12), random.randint(1, 28), random.randint(1, 999))
    y = 0
    for i in range(17):
        y += int(x[i]) * ARR[i]
    IDCard = '%s%s' % (x, LAST[y % 11])
    # birthday = '%s-%s-%s 00:00:00' % (IDCard[6:14][0:4], IDCard[6:14][4: 6], IDCard[6:14][6:8])
    return IDCard



# def checkholiday(date):
#     server_url = "http://www.easybots.cn/api/holiday.php?d="
#     vop_url_request = urllib2.Request(server_url + date)
#     vop_response = urllib2.urlopen(vop_url_request)
#     vop_data = json.loads(vop_response.read())
#     if vop_data[date] == '0':
#         return 0
#     elif vop_data[date] == '1':
#         return 1
#     elif vop_data[date] == '2':
#         return 2
#     else:
#         return 'error'




# ***********************
# description：api gateway sdk
# author：喻珩
# create time：2018.6.14
# ***********************

import datetime
import pytz
import urllib.parse

def url_encoder(params):
    g_encode_params = {}

    def _encode_params(params, p_key=None):
        encode_params = {}
        if isinstance(params, dict):
            for key in params:
                encode_key = '{}[{}]'.format(p_key,key)
                encode_params[encode_key] = params[key]
        elif isinstance(params, (list, tuple)):
            for offset,value in enumerate(params):
                encode_key = '{}[{}]'.format(p_key, offset)
                encode_params[encode_key] = value
        else:
            g_encode_params[p_key] = params

        for key in encode_params:
            value = encode_params[key]
            _encode_params(value, key)

    if isinstance(params, dict):
        for key in params:
            _encode_params(params[key], key)
    print(g_encode_params)
    return urllib.parse.urlencode(g_encode_params)

def get_gmt_time():
    tz = pytz.timezone('GMT')
    return datetime.datetime.now(tz).strftime("%a, %d %h %Y %H:%M:%S GMT")