# ***********************
# description：api gateway test
# author：喻珩
# create time：2018.7.18
# ***********************
from qalib.apiGateway import KongClient
from multiprocessing.pool import ThreadPool
import threading
import queue
import json
import time

class gatewayTest():
    kong_client = KongClient(
        kongBaseUrl="http://api-test.sunlands.com",
        appKey="yuheng_app_test",
        appSecret="6p1pSkCMYH6QnqlplxRlIniCQrTRcubX"
    )
    __thread_pool__ = ThreadPool(32)
    success_num = 0
    fail_num = 0

    def get_sec(self, unit):
        if unit not in ["s","m","h","d"]:
            raise Exception("unit error")
        s_map = {
            "s": 1,
            "m": 60,
            "h": 3600,
            "d": 86400
        }
        return s_map[unit]

    def rateLimitTest(self, limit, unit):
        import time
        n, n_succ, n_fail = 0, 0, 0
        start_time = time.strftime("%H-%M-%S")
        start_us = int(round(time.time() * 1000000))
        t_us = start_us
        while t_us - start_us < 1000000 * self.get_sec(unit):
            result = self.kong_client.get('/yuhengTest1/yuhengAclTest')
            n = n + 1
            t_us = int(round(time.time() * 1000000))
            print(result.content)
            if result.status_code == 200:
                n_succ = n_succ + 1
            elif result.status_code == 429:
                break
            else:
                raise Exception("error status code")
        end_time = time.strftime("%H-%M-%S")
        print("start time: %s; end_time: %s" % (start_time, end_time))
        print("time stamp us:" + str(t_us - start_us))
        print("n_succ:" + str(n_succ))
        print("limit:" + str(limit))
        # assert n_succ == limit


    def ob_fun(self):
        rsp = self.kong_client.get('/yuhengTest1/yuhengAclTest')
        ret = json.loads(rsp.content)
        try:
            if ret["code"] == 0:
                self.success_num = self.success_num + 1
            else:
                self.fail_num = self.fail_num + 1
        except KeyError:
            self.fail_num = self.fail_num + 1
        # print(ret)
        return ret

    def run_async(self, func, *args, **kwargs):
        # def on_complete(self, result):
        #     try:
        #         if result["code"] == 0:
        #             self.success_num = self.success_num + 1
        #         else:
        #             self.fail_num = self.fail_num + 1
        #     except KeyError:
        #         self.fail_num = self.fail_num + 1
        #     # print(result)
        return self.__thread_pool__.apply_async(func, args, kwargs)

    def multi_run(self):
        fun_name = "ob_fun"
        start_us = int(round(time.time() * 1000000))
        t_us = start_us
        n = 0
        while t_us - start_us < 1000000*10:
            n = n + 1
            self.run_async(getattr(self, fun_name))
            t_us = int(round(time.time() * 1000000))
        print("time stamp s:" + str(1.0 * (t_us - start_us) / 1000000))
        print("success number:" + str(self.success_num))
        print("fail number:" + str(self.fail_num))
        print("total n:" + str(n))

if __name__ == "__main__":
    gt = gatewayTest()
    gt.multi_run()