from django.db import models

from qalib.common import paramcommon

'''用户类型表操作'''


class MqToolInfoManager(models.Manager):
    """
    mq工具管理
    """
    def get_mqtool_by_id(self, index, type=True):
        if type:
            return self.filter(id=index).all()
        else:
            return self.get(id=index).name

    def get_mqtool_name(self, mqtool_name, type=True, id=None):
        if type:
            return self.filter(name__exact=mqtool_name).count()
        else:
            if id is not None:
                return self.get(id=id).name
            else:
                raise Exception("miss id param")

    def insert_mqtool(self, **kwargs):
        self.create(**kwargs)

    def update_mqtool(self, id, **kwargs):
        obj = self.get(id=id)
        obj.name = kwargs.get('name')
        obj.producerid = kwargs.get("producerid")
        obj.secretkey = kwargs.get("secretkey")
        obj.appid = kwargs.get("appid")
        obj.author = kwargs.get("author")
        obj.belong_project = kwargs.get("belong_project")
        obj.msg_topic = kwargs.get("msg_topic")
        obj.msg_body = kwargs.get("msg_body")
        obj.topic_tag = kwargs.get("topic_tag")
        obj.proxyurl = kwargs.get("proxyurl")
        obj.save()



class ehrmoduleManager(models.Manager):
    """
    ehr数据模板
    """
    def get_ehrmodule_by_id(self, index, type=True):
        if type:
            return self.filter(id=index).all()
        else:
            return self.get(id=index).name

    def get_casename(self, casename, type=True, id=None):
        if type:
            return self.filter(casename__exact=casename).count()
        else:
            if id is not None:
                return self.get(id=id).name
            else:
                raise Exception("miss id param")


    def createerhmodule(self, **kwargs):
        """
        Create a new object with the given kwargs, saving it to the database
        and returning the created object.
        """
        obj = self.model(**kwargs)
        obj.casename = kwargs.get('casename')
        obj.contract_type = kwargs.get("contract_type")
        obj.city = kwargs.get("city")
        obj.type = kwargs.get("type")
        obj.pay_city = kwargs.get("pay_city")
        obj.is_51 = kwargs.get("is_51")
        obj.num_51_agency = kwargs.get("num_51_agency")
        obj.work_state = kwargs.get("work_state")
        obj.country = kwargs.get("country")
        obj.entry_dt = paramcommon(kwargs.get("entry_dt"))
        obj.train_salary = kwargs.get("train_salary")
        obj.base_salary_before = kwargs.get("base_salary_before")
        obj.base_salary = kwargs.get("base_salary")
        obj.pos_salary_before = kwargs.get("pos_salary_before")
        obj.pos_salary = kwargs.get("pos_salary")
        obj.leave_work_statu_before = kwargs.get("leave_work_statu_before")
        obj.the_last_dt = paramcommon(kwargs.get("the_last_dt"))
        obj.start_train_dt = paramcommon(kwargs.get("start_train_dt"))
        obj.end_train_dt = paramcommon(kwargs.get("end_train_dt"))
        obj.work_category = kwargs.get("work_category")
        obj.org_id = kwargs.get("org_id")
        obj.organization_source = kwargs.get("organization_source")
        obj.regular_salary_before = kwargs.get("regular_salary_before")
        obj.regular_salary_after = kwargs.get("regular_salary_after")
        obj.regular_dt = paramcommon(kwargs.get("regular_dt"))
        obj.regular_type = kwargs.get("regular_type")
        obj.salary_change_before = kwargs.get("salary_change_before")
        obj.salary_change_after = kwargs.get("salary_change_after")
        obj.salary_change_pos_before = kwargs.get("salary_change_pos_before")
        obj.salary_change_pos_after = kwargs.get("salary_change_pos_after")
        obj.salary_change_dt = paramcommon(kwargs.get("salary_change_dt"))
        obj.salary_change_type = kwargs.get("salary_change_type")
        obj.attendance_statistic = kwargs.get("attendance_statistic")
        obj.schedule_plan = kwargs.get("schedule_plan")
        self._for_write = True
        obj.save(force_insert=True, using=self.db)
        return obj

    def update_ehrdate(self, id, **kwargs):
        obj = self.get(id=id)
        obj.casename = kwargs.get('casename')
        obj.contract_type = kwargs.get("contract_type")
        obj.city = kwargs.get("city")
        obj.type = kwargs.get("type")
        obj.pay_city = kwargs.get("pay_city")
        obj.is_51 = kwargs.get("is_51")
        obj.num_51_agency = kwargs.get("num_51_agency")
        obj.work_state = kwargs.get("work_state")
        obj.country = kwargs.get("country")
        obj.entry_dt = paramcommon(kwargs.get("entry_dt"))
        obj.train_salary = kwargs.get("train_salary")
        obj.base_salary_before = kwargs.get("base_salary_before")
        obj.base_salary = kwargs.get("base_salary")
        obj.pos_salary_before = kwargs.get("pos_salary_before")
        obj.pos_salary = kwargs.get("pos_salary")
        obj.leave_work_statu_before = kwargs.get("leave_work_statu_before")
        obj.the_last_dt = paramcommon(kwargs.get("the_last_dt"))
        obj.start_train_dt = paramcommon(kwargs.get("start_train_dt"))
        obj.end_train_dt = paramcommon(kwargs.get("end_train_dt"))
        obj.work_category = kwargs.get("work_category")
        obj.org_id = kwargs.get("org_id")
        obj.organization_source = kwargs.get("organization_source")
        obj.regular_salary_before = kwargs.get("regular_salary_before")
        obj.regular_salary_after = kwargs.get("regular_salary_after")
        obj.regular_dt = paramcommon(kwargs.get("regular_dt"))
        obj.regular_type = kwargs.get("regular_type")
        obj.salary_change_before = kwargs.get("salary_change_before")
        obj.salary_change_after = kwargs.get("salary_change_after")
        obj.salary_change_pos_before = kwargs.get("salary_change_pos_before")
        obj.salary_change_pos_after = kwargs.get("salary_change_pos_after")
        obj.salary_change_dt = paramcommon(kwargs.get("salary_change_dt"))
        obj.salary_change_type = kwargs.get("salary_change_type")
        obj.attendance_statistic = kwargs.get("attendance_statistic")
        obj.schedule_plan = kwargs.get("schedule_plan")
        print(obj)
        obj.save()

