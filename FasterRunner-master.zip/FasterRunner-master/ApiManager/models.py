from django.db import models

from ApiManager.managers import MqToolInfoManager,ehrmoduleManager


# Create your models here.


class BaseTable(models.Model):
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    update_time = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        abstract = True
        verbose_name = "公共字段表"
        db_table = 'BaseTable'

class ehr_module_employee(BaseTable):
    class Meta:
        verbose_name = "mq工具信息"
        db_table = "ehrmodule"
    casename = models.CharField('模板名称', max_length=500)
    contract_type = models.CharField('合同性质', max_length=4,blank=True,null=True)
    city = models.CharField('地域隶属', max_length=4,blank=True,null=True)
    type = models.CharField('员工类型', max_length=4,blank=True,null=True)
    pay_city = models.CharField('发薪地域隶属', max_length=4,blank=True,null=True)
    is_51 = models.CharField('是否51代发', max_length=16,blank=True,null=True)
    num_51_agency = models.CharField('51代发账号数', max_length=20,blank=True,null=True)
    work_state = models.CharField('任职状态', max_length=4,blank=True,null=True)
    country = models.CharField('国家', max_length=50,blank=True,null=True)
    entry_dt = models.DateField('入职日期', max_length=50,blank=True,null=True)
    train_salary = models.CharField('实习工资', max_length=25,blank=True,null=True)
    base_salary_before = models.CharField('试用期工资', max_length=25,blank=True,null=True)
    base_salary = models.CharField('正式工资', max_length=25,blank=True,null=True)
    pos_salary_before = models.CharField('试用期岗位工资', max_length=25,blank=True,null=True)
    pos_salary = models.CharField('正式岗位工资', max_length=25,blank=True,null=True)
    leave_work_statu_before = models.CharField('离职前任职状态', max_length=4,blank=True,null=True)
    the_last_dt = models.DateField('最后工作日', max_length=50,blank=True,null=True)
    start_train_dt = models.DateField('参培开始日期', max_length=50,blank=True,null=True)
    end_train_dt = models.DateField('参培结束日期', max_length=50,blank=True,null=True)
    work_category = models.CharField('职族', max_length=25,blank=True,null=True)
    org_id = models.CharField('部门ID', max_length=25,blank=True,null=True)
    organization_source = models.CharField("部门表源目录", max_length=50,blank=True,null=True)
    regular_salary_before = models.CharField("转正前工资", max_length=25,blank=True,null=True)
    regular_salary_after = models.CharField("转正后工资",max_length=25,blank=True,null=True)
    regular_dt = models.DateTimeField("转正生效日期", max_length=50,blank=True,null=True)
    regular_type = models.CharField("转正类型", max_length=4,blank=True,null=True)
    salary_change_before = models.CharField("调薪前工资", max_length=25,blank=True,null=True)
    salary_change_after = models.CharField("调薪后工资", max_length=25,blank=True,null=True)
    salary_change_pos_before = models.CharField("调薪前岗位工资", max_length=25,blank=True,null=True)
    salary_change_pos_after = models.CharField("调薪后岗位工资", max_length=25,blank=True,null=True)
    salary_change_dt = models.DateField("调薪生效日期", max_length=50,blank=True,null=True)
    salary_change_type = models.CharField("调薪类型", max_length=25,blank=True,null=True)
    attendance_statistic = models.TextField("考勤统计信息",blank=True,null=True)
    schedule_plan = models.TextField("排班信息", blank=True, null=True)
    objects = ehrmoduleManager()
